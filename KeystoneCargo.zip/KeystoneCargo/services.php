<?php
include("includes/header.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Services | Keystone Cargo</title>

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

</head>


<body>


<!-- =========================================================
     SERVICES PAGE
     ========================================================= -->

<section class="kc-services-page">


    <div class="kc-services-container">


        <!-- =================================================
             PAGE HEADER
             ================================================= -->

        <div class="kc-services-header">


            <!-- ICON -->

            <div class="kc-services-main-icon">

                <i class="fas fa-truck-fast"></i>

            </div>


            <!-- TITLE -->

            <h1>
                Our <span>Services</span>
            </h1>


            <!-- DESCRIPTION -->

            <p>
                Professional parcel management and delivery services
                designed to make shipping simple, secure and transparent.
            </p>


        </div>



        <!-- =================================================
             SERVICES CARDS
             ================================================= -->

        <div class="kc-services-grid">


            <!-- ================= SERVICE 1 ================= -->

            <div class="kc-service-card">


                <div class="kc-service-icon">

                    <i class="fas fa-box"></i>

                </div>


                <h3>
                    Parcel Management
                </h3>


                <p>
                    Easily manage parcel bookings, sender details,
                    receiver information and delivery details from
                    one centralized system.
                </p>


                <a
                    href="track.php"
                    class="kc-service-link"
                >

                    Track Parcel

                    <i class="fas fa-arrow-right"></i>

                </a>


            </div>



            <!-- ================= SERVICE 2 ================= -->

            <div class="kc-service-card">


                <div class="kc-service-icon">

                    <i class="fas fa-location-dot"></i>

                </div>


                <h3>
                    Real-Time Tracking
                </h3>


                <p>
                    Customers can enter their tracking number and
                    view the current location, status and progress
                    of their parcel.
                </p>


                <a
                    href="track.php"
                    class="kc-service-link"
                >

                    Track Now

                    <i class="fas fa-arrow-right"></i>

                </a>


            </div>



            <!-- ================= SERVICE 3 ================= -->

            <div class="kc-service-card">


                <div class="kc-service-icon">

                    <i class="fas fa-truck-fast"></i>

                </div>


                <h3>
                    Fast Delivery
                </h3>


                <p>
                    Keep track of parcel movement through every
                    stage of the delivery process, from booking
                    to final delivery.
                </p>


                <a
                    href="track.php"
                    class="kc-service-link"
                >

                    View Delivery

                    <i class="fas fa-arrow-right"></i>

                </a>


            </div>



            <!-- ================= SERVICE 4 ================= -->

            <div class="kc-service-card">


                <div class="kc-service-icon">

                    <i class="fas fa-shield-halved"></i>

                </div>


                <h3>
                    Secure Administration
                </h3>


                <p>
                    Administrators can securely manage customer,
                    parcel and tracking information through the
                    dedicated administration panel.
                </p>


                <a
                    href="admin/login.php"
                    class="kc-service-link"
                >

                    Admin Login

                    <i class="fas fa-arrow-right"></i>

                </a>


            </div>



            <!-- ================= SERVICE 5 ================= -->

            <div class="kc-service-card">


                <div class="kc-service-icon">

                    <i class="fas fa-clock"></i>

                </div>


                <h3>
                    Delivery Updates
                </h3>


                <p>
                    Parcel status updates help customers understand
                    whether their shipment is booked, packed,
                    in transit or delivered.
                </p>


                <a
                    href="track.php"
                    class="kc-service-link"
                >

                    Check Status

                    <i class="fas fa-arrow-right"></i>

                </a>


            </div>



            <!-- ================= SERVICE 6 ================= -->

            <div class="kc-service-card">


                <div class="kc-service-icon">

                    <i class="fas fa-headset"></i>

                </div>


                <h3>
                    Customer Support
                </h3>


                <p>
                    Keystone Cargo provides a simple and organized
                    system for handling parcel information and
                    keeping customers informed.
                </p>


                <a
                    href="contact.php"
                    class="kc-service-link"
                >

                    Contact Us

                    <i class="fas fa-arrow-right"></i>

                </a>


            </div>


        </div>



        <!-- =================================================
             BACK TO HOME
             ================================================= -->

        <div class="kc-back-home-container">


            <a
                href="index.php"
                class="kc-back-home"
            >

                <i class="fas fa-arrow-left"></i>

                Back to Home

            </a>


        </div>


    </div>


</section>



<!-- =========================================================
     SERVICES PAGE CSS
     ========================================================= -->

<style>


/* =========================================================
   MAIN SERVICES PAGE
   ========================================================= */

.kc-services-page {

    width: 100%;

    min-height: calc(100vh - 82px);

    padding: 75px 5% 90px;

    background:

        radial-gradient(
            circle at 8% 25%,
            rgba(18, 104, 232, 0.10),
            transparent 30%
        ),

        radial-gradient(
            circle at 92% 75%,
            rgba(18, 104, 232, 0.08),
            transparent 30%
        ),

        linear-gradient(
            135deg,
            #f3f7ff 0%,
            #ffffff 50%,
            #eef5ff 100%
        );

}


/* =========================================================
   MAIN CONTAINER
   ========================================================= */

.kc-services-container {

    width: 100%;

    max-width: 1400px;

    margin: 0 auto;

}


/* =========================================================
   HEADER
   ========================================================= */

.kc-services-header {

    width: 100%;

    max-width: 900px;

    margin: 0 auto 60px;

    text-align: center;

}


/* =========================================================
   MAIN ICON
   ========================================================= */

.kc-services-main-icon {

    width: 90px;

    height: 90px;

    margin: 0 auto 28px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            #1976f3,
            #075dcc
        );

    color: #ffffff;

    font-size: 36px;

    box-shadow:
        0 18px 40px
        rgba(18, 104, 232, 0.22);

}


/* =========================================================
   PAGE TITLE
   ========================================================= */

.kc-services-header h1 {

    margin: 0 0 20px;

    font-size: clamp(42px, 6vw, 68px);

    line-height: 1.1;

    font-weight: 800;

    letter-spacing: -2px;

    color: #082b63;

}


.kc-services-header h1 span {

    color: #1268e8;

}


/* =========================================================
   DESCRIPTION
   ========================================================= */

.kc-services-header p {

    max-width: 800px;

    margin: 0 auto;

    color: #64748b;

    font-size: 18px;

    line-height: 1.8;

}


/* =========================================================
   SERVICES GRID
   ========================================================= */

.kc-services-grid {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 30px;

}


/* =========================================================
   SERVICE CARD
   ========================================================= */

.kc-service-card {

    min-height: 315px;

    padding: 35px;

    background: #ffffff;

    border: 1px solid #e1eaf7;

    border-radius: 22px;

    box-shadow:
        0 15px 40px
        rgba(18, 104, 232, 0.07);

    transition:
        transform 0.3s ease,
        box-shadow 0.3s ease,
        border-color 0.3s ease;

}


.kc-service-card:hover {

    transform: translateY(-8px);

    border-color:
        rgba(18, 104, 232, 0.25);

    box-shadow:
        0 25px 55px
        rgba(18, 104, 232, 0.15);

}


/* =========================================================
   CARD ICON
   ========================================================= */

.kc-service-icon {

    width: 58px;

    height: 58px;

    margin-bottom: 22px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 15px;

    background: #eaf3ff;

    color: #1268e8;

    font-size: 24px;

    transition: all 0.3s ease;

}


.kc-service-card:hover
.kc-service-icon {

    background: #1268e8;

    color: #ffffff;

    transform: scale(1.05);

}


/* =========================================================
   CARD TITLE
   ========================================================= */

.kc-service-card h3 {

    margin: 0 0 15px;

    color: #082b63;

    font-size: 22px;

    font-weight: 700;

}


/* =========================================================
   CARD DESCRIPTION
   ========================================================= */

.kc-service-card p {

    margin: 0 0 22px;

    color: #64748b;

    font-size: 15px;

    line-height: 1.8;

}


/* =========================================================
   CARD LINK
   ========================================================= */

.kc-service-link {

    display: inline-flex;

    align-items: center;

    gap: 8px;

    color: #1268e8 !important;

    font-size: 15px;

    font-weight: 600;

    text-decoration: none !important;

    transition: all 0.25s ease;

}


.kc-service-link:hover {

    color: #084da8 !important;

    gap: 12px;

}


/* =========================================================
   BACK TO HOME CONTAINER
   ========================================================= */

.kc-back-home-container {

    width: 100%;

    display: flex;

    justify-content: center;

    margin-top: 60px;

}


/* =========================================================
   BACK TO HOME BUTTON
   ========================================================= */

.kc-back-home {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 10px;

    padding: 13px 28px;

    background: #1268e8;

    color: #ffffff !important;

    border-radius: 30px;

    font-size: 16px;

    font-weight: 600;

    text-decoration: none !important;

    box-shadow:
        0 8px 22px
        rgba(18, 104, 232, 0.20);

    transition: all 0.25s ease;

}


.kc-back-home i {

    font-size: 15px;

}


.kc-back-home:hover {

    background: #0b55c4;

    color: #ffffff !important;

    transform: translateY(-3px);

    box-shadow:
        0 12px 28px
        rgba(18, 104, 232, 0.28);

}


/* =========================================================
   TABLET
   ========================================================= */

@media (max-width: 1000px) {

    .kc-services-grid {

        grid-template-columns:
            repeat(2, 1fr);

    }

}


/* =========================================================
   MOBILE
   ========================================================= */

@media (max-width: 650px) {

    .kc-services-page {

        padding:
            55px 6% 70px;

    }


    .kc-services-header {

        margin-bottom: 45px;

    }


    .kc-services-main-icon {

        width: 75px;

        height: 75px;

        font-size: 30px;

        border-radius: 18px;

    }


    .kc-services-header h1 {

        font-size: 42px;

        letter-spacing: -1px;

    }


    .kc-services-header p {

        font-size: 15px;

        line-height: 1.7;

    }


    .kc-services-grid {

        grid-template-columns: 1fr;

        gap: 20px;

    }


    .kc-service-card {

        min-height: auto;

        padding: 28px;

    }


    .kc-back-home-container {

        margin-top: 45px;

    }

}


</style>



<?php
include("includes/footer.php");
?>
