<?php
session_start();

include("../includes/db.php");

/* Check admin login */
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$message = "";
$error = "";

/* =========================
   GENERATE TRACKING NUMBER
========================= */

$sql = "SELECT MAX(parcel_id) AS max_id FROM parcel";

$result = mysqli_query($conn, $sql);

$row = mysqli_fetch_assoc($result);

$next_id = ($row['max_id'] ?? 0) + 1;

$tracking_number = "KC" . str_pad($next_id, 4, "0", STR_PAD_LEFT);


/* =========================
   GET CUSTOMERS
========================= */

$customer_sql = "SELECT customer_id, full_name, phone, address
                 FROM customer
                 ORDER BY full_name ASC";

$customer_result = mysqli_query($conn, $customer_sql);


/* =========================
   FORM SUBMISSION
========================= */

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $customer_id = intval($_POST['customer_id']);
    $receiver_name = trim($_POST['receiver_name']);
    $receiver_phone = trim($_POST['receiver_phone']);
    $receiver_address = trim($_POST['receiver_address']);
    $parcel_type = trim($_POST['parcel_type']);
    $weight = trim($_POST['weight']);
    $sender_address = trim($_POST['sender_address']);
    $estimated_delivery = trim($_POST['estimated_delivery']);

    $status = "Booked";

    /* Validation */

    if (
        $customer_id <= 0 ||
        $receiver_name == "" ||
        $receiver_phone == "" ||
        $receiver_address == "" ||
        $parcel_type == "" ||
        $weight == "" ||
        $sender_address == "" ||
        $estimated_delivery == ""
    ) {

        $error = "Please fill in all fields.";

    } elseif (!is_numeric($weight) || $weight <= 0) {

        $error = "Please enter a valid parcel weight.";

    } else {

        /* Insert parcel */

        $insert_sql = "INSERT INTO parcel
        (
            tracking_number,
            customer_id,
            receiver_name,
            receiver_phone,
            receiver_address,
            parcel_type,
            weight,
            booking_date,
            status,
            sender_address,
            estimated_delivery
        )
        VALUES
        (?, ?, ?, ?, ?, ?, ?, CURDATE(), ?, ?, ?)";

        $stmt = mysqli_prepare($conn, $insert_sql);

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                "sissssdsss",
                $tracking_number,
                $customer_id,
                $receiver_name,
                $receiver_phone,
                $receiver_address,
                $parcel_type,
                $weight,
                $status,
                $sender_address,
                $estimated_delivery
            );

            if (mysqli_stmt_execute($stmt)) {

                $parcel_id = mysqli_insert_id($conn);

                /*
                   Add first tracking history record
                */

                $history_sql = "INSERT INTO tracking_history
                (
                    parcel_id,
                    status,
                    location,
                    remarks,
                    updated_at
                )
                VALUES
                (?, ?, ?, ?, NOW())";

                $history_stmt = mysqli_prepare(
                    $conn,
                    $history_sql
                );

                if ($history_stmt) {

                    $location = "Booking Office";
                    $remarks = "Parcel booked successfully.";

                    mysqli_stmt_bind_param(
                        $history_stmt,
                        "isss",
                        $parcel_id,
                        $status,
                        $location,
                        $remarks
                    );

                    mysqli_stmt_execute($history_stmt);

                    mysqli_stmt_close($history_stmt);
                }

                mysqli_stmt_close($stmt);

                header(
                    "Location: view_parcel.php?added=1&tracking="
                    . urlencode($tracking_number)
                );

                exit();

            } else {

                $error = "Unable to save parcel: "
                       . mysqli_error($conn);
            }

            mysqli_stmt_close($stmt);

        } else {

            $error = "Unable to prepare parcel query.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Book Parcel | Keystone Cargo</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial,sans-serif;
}

body{
    background:#f4f7fc;
    color:#102a56;
}

/* ================= NAVBAR ================= */

.navbar{
    height:80px;
    background:linear-gradient(90deg,#0d3b82,#1269ed);
    display:flex;
    align-items:center;
    padding:0 5%;
    color:white;
}

.logo{
    display:flex;
    align-items:center;
    gap:12px;
}

.logo i{
    font-size:30px;
    color:#ffc107;
}

.logo h2{
    font-size:25px;
}

.nav-right{
    margin-left:auto;
    display:flex;
    align-items:center;
    gap:25px;
}

.nav-right a{
    color:white;
    text-decoration:none;
    font-size:16px;
}

.nav-right a:hover{
    color:#ffc107;
}

/* ================= CONTAINER ================= */

.container{
    width:92%;
    max-width:1000px;
    margin:45px auto;
}

/* ================= CARD ================= */

.card{
    background:white;
    padding:40px;
    border-radius:20px;
    box-shadow:0 12px 35px rgba(0,0,0,0.08);
}

.title{
    text-align:center;
    margin-bottom:35px;
}

.title h1{
    font-size:36px;
    color:#102a56;
}

.title h1 i{
    color:#1269ed;
}

.title p{
    margin-top:8px;
    color:#777;
}

/* ================= TRACKING ================= */

.tracking-box{
    background:#eaf2ff;
    border:1px solid #c9dcff;
    padding:20px;
    border-radius:12px;
    margin-bottom:30px;
    text-align:center;
}

.tracking-label{
    color:#666;
    font-size:15px;
    margin-bottom:6px;
}

.tracking-number{
    color:#1269ed;
    font-size:28px;
    font-weight:bold;
}

/* ================= FORM ================= */

.form-row{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
}

.form-group{
    margin-bottom:20px;
}

.full{
    grid-column:1 / -1;
}

.form-group label{
    display:block;
    font-weight:bold;
    margin-bottom:8px;
    color:#102a56;
}

.form-group input,
.form-group select,
.form-group textarea{
    width:100%;
    padding:14px 16px;
    border:1px solid #d5deeb;
    border-radius:10px;
    font-size:16px;
    outline:none;
    background:white;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus{
    border-color:#1269ed;
    box-shadow:0 0 0 3px rgba(18,105,237,0.10);
}

.form-group textarea{
    min-height:110px;
    resize:vertical;
}

/* ================= SENDER INFO ================= */

.sender-info{
    background:#f5f8fd;
    border-radius:10px;
    padding:15px;
    margin-top:-8px;
    margin-bottom:20px;
    color:#555;
    display:none;
}

.sender-info strong{
    color:#102a56;
}

/* ================= MESSAGE ================= */

.error{
    background:#ffe0e0;
    color:#9b1c1c;
    border:1px solid #ffb3b3;
    padding:15px;
    border-radius:10px;
    margin-bottom:25px;
}

/* ================= BUTTONS ================= */

.buttons{
    display:flex;
    gap:15px;
    margin-top:10px;
}

.btn{
    flex:1;
    padding:16px;
    border:none;
    border-radius:10px;
    font-size:17px;
    font-weight:bold;
    cursor:pointer;
    text-decoration:none;
    text-align:center;
}

.save-btn{
    background:#1269ed;
    color:white;
}

.save-btn:hover{
    background:#0d56c7;
}

.cancel-btn{
    background:#e9edf3;
    color:#333;
}

.cancel-btn:hover{
    background:#dce2ea;
}

/* ================= RESPONSIVE ================= */

@media(max-width:700px){

    .navbar{
        height:auto;
        padding:18px 20px;
        flex-direction:column;
        gap:15px;
    }

    .nav-right{
        margin-left:0;
    }

    .form-row{
        grid-template-columns:1fr;
    }

    .full{
        grid-column:auto;
    }

    .card{
        padding:25px;
    }

    .buttons{
        flex-direction:column;
    }

}

</style>

</head>

<body>

<!-- ================= NAVBAR ================= -->

<nav class="navbar">

    <div class="logo">

        <i class="fa-solid fa-truck-fast"></i>

        <h2>
            Keystone Cargo
        </h2>

    </div>

    <div class="nav-right">

        <a href="dashboard.php">

            <i class="fa-solid fa-gauge"></i>

            Dashboard

        </a>

        <a href="view_parcel.php">

            <i class="fa-solid fa-box"></i>

            Parcels

        </a>

        <a href="logout.php">

            <i class="fa-solid fa-right-from-bracket"></i>

            Logout

        </a>

    </div>

</nav>


<!-- ================= MAIN ================= -->

<div class="container">

    <div class="card">

        <div class="title">

            <h1>

                <i class="fa-solid fa-box-open"></i>

                Book New Parcel

            </h1>

            <p>
                Enter the parcel details below
            </p>

        </div>


        <!-- TRACKING NUMBER -->

        <div class="tracking-box">

            <div class="tracking-label">
                Automatically Generated Tracking Number
            </div>

            <div class="tracking-number">

                <?php
                echo htmlspecialchars($tracking_number);
                ?>

            </div>

        </div>


        <?php if ($error != ""): ?>

            <div class="error">

                <i class="fa-solid fa-circle-exclamation"></i>

                <?php
                echo htmlspecialchars($error);
                ?>

            </div>

        <?php endif; ?>


        <form method="POST">


            <div class="form-row">


                <!-- SENDER -->

                <div class="form-group">

                    <label>

                        Sender / Customer

                    </label>

                    <select
                        name="customer_id"
                        id="customer_id"
                        required
                        onchange="showSender()">

                        <option value="">
                            Select Customer
                        </option>

                        <?php

                        mysqli_data_seek(
                            $customer_result,
                            0
                        );

                        while (
                            $customer =
                            mysqli_fetch_assoc(
                                $customer_result
                            )
                        ):

                        ?>

                            <option
                                value="<?php echo $customer['customer_id']; ?>"
                                data-phone="<?php echo htmlspecialchars($customer['phone']); ?>"
                                data-address="<?php echo htmlspecialchars($customer['address']); ?>">

                                <?php
                                echo htmlspecialchars(
                                    $customer['full_name']
                                );
                                ?>

                            </option>

                        <?php endwhile; ?>

                    </select>

                </div>


                <!-- RECEIVER NAME -->

                <div class="form-group">

                    <label>
                        Receiver Name
                    </label>

                    <input
                        type="text"
                        name="receiver_name"
                        placeholder="Enter receiver name"
                        required
                    >

                </div>


                <!-- SENDER ADDRESS -->

                <div class="form-group">

                    <label>
                        Sender Address
                    </label>

                    <textarea
                        name="sender_address"
                        id="sender_address"
                        placeholder="Enter sender address"
                        required
                    ></textarea>

                </div>


                <!-- RECEIVER ADDRESS -->

                <div class="form-group">

                    <label>
                        Receiver Address
                    </label>

                    <textarea
                        name="receiver_address"
                        placeholder="Enter receiver address"
                        required
                    ></textarea>

                </div>


                <!-- RECEIVER PHONE -->

                <div class="form-group">

                    <label>
                        Receiver Phone
                    </label>

                    <input
                        type="text"
                        name="receiver_phone"
                        placeholder="Enter receiver phone"
                        required
                    >

                </div>


                <!-- PARCEL TYPE -->

                <div class="form-group">

                    <label>
                        Parcel Type
                    </label>

                    <select
                        name="parcel_type"
                        required>

                        <option value="">
                            Select Parcel Type
                        </option>

                        <option value="Document">
                            Document
                        </option>

                        <option value="Package">
                            Package
                        </option>

                        <option value="Electronics">
                            Electronics
                        </option>

                        <option value="Clothing">
                            Clothing
                        </option>

                        <option value="Fragile">
                            Fragile
                        </option>

                        <option value="Other">
                            Other
                        </option>

                    </select>

                </div>


                <!-- WEIGHT -->

                <div class="form-group">

                    <label>
                        Weight (kg)
                    </label>

                    <input
                        type="number"
                        name="weight"
                        step="0.01"
                        min="0.01"
                        placeholder="Example: 2.5"
                        required
                    >

                </div>


                <!-- ESTIMATED DELIVERY -->

                <div class="form-group">

                    <label>
                        Estimated Delivery
                    </label>

                    <input
                        type="date"
                        name="estimated_delivery"
                        min="<?php echo date('Y-m-d'); ?>"
                        required
                    >

                </div>

            </div>


            <!-- BUTTONS -->

            <div class="buttons">

                <button
                    type="submit"
                    class="btn save-btn">

                    <i class="fa-solid fa-box"></i>

                    Book Parcel

                </button>


                <a
                    href="view_parcel.php"
                    class="btn cancel-btn">

                    <i class="fa-solid fa-xmark"></i>

                    Cancel

                </a>

            </div>

        </form>

    </div>

</div>


<script>

/* Automatically fill sender address */

function showSender(){

    const select =
        document.getElementById("customer_id");

    const address =
        document.getElementById("sender_address");

    const option =
        select.options[select.selectedIndex];

    if(option && option.dataset.address){

        address.value =
            option.dataset.address;

    }else{

        address.value = "";

    }
}

</script>

</body>

</html>