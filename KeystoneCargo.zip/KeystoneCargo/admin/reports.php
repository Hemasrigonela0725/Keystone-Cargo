<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include("../includes/db.php");


/* =========================================
   PARCEL COUNTS
========================================= */

function getCount($conn, $status = null)
{
    if ($status === null) {

        $sql = "SELECT COUNT(*) AS total FROM parcel";

    } else {

        $sql = "SELECT COUNT(*) AS total
                FROM parcel
                WHERE status = ?";

    }


    if ($status === null) {

        $result = mysqli_query($conn, $sql);

    } else {

        $stmt = mysqli_prepare($conn, $sql);

        mysqli_stmt_bind_param(
            $stmt,
            "s",
            $status
        );

        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);
    }


    $row = mysqli_fetch_assoc($result);

    return $row['total'] ?? 0;
}


/* =========================================
   GET ALL COUNTS
========================================= */

$totalParcels = getCount($conn);

$booked = getCount(
    $conn,
    "Booked"
);

$packed = getCount(
    $conn,
    "Packed"
);

$inTransit = getCount(
    $conn,
    "In Transit"
);

$outForDelivery = getCount(
    $conn,
    "Out for Delivery"
);

$delivered = getCount(
    $conn,
    "Delivered"
);


/* =========================================
   CUSTOMER COUNT
========================================= */

$customerResult = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM customer"
);

$customerRow = mysqli_fetch_assoc(
    $customerResult
);

$totalCustomers = $customerRow['total'] ?? 0;


/* =========================================
   RECENT PARCELS
========================================= */

$recentSql = "

    SELECT
        p.parcel_id,
        p.tracking_number,
        p.receiver_name,
        p.parcel_type,
        p.weight,
        p.booking_date,
        p.status,
        c.full_name AS sender_name

    FROM parcel p

    LEFT JOIN customer c
        ON p.customer_id = c.customer_id

    ORDER BY p.parcel_id DESC

    LIMIT 10

";

$recentParcels = mysqli_query(
    $conn,
    $recentSql
);


/* =========================================
   STATUS PERCENTAGES
========================================= */

function percentage($value, $total)
{
    if ($total == 0) {
        return 0;
    }

    return round(
        ($value / $total) * 100
    );
}


$bookedPercent = percentage(
    $booked,
    $totalParcels
);

$packedPercent = percentage(
    $packed,
    $totalParcels
);

$transitPercent = percentage(
    $inTransit,
    $totalParcels
);

$outPercent = percentage(
    $outForDelivery,
    $totalParcels
);

$deliveredPercent = percentage(
    $delivered,
    $totalParcels
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>
        Reports | Keystone Cargo
    </title>


    <link rel="stylesheet"
          href="../assets/css/admin.css">


    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


    <style>

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            font-family: Arial, sans-serif;

            background: #f4f7fc;

            color: #222;

        }


        .page-container {

            margin-left: 270px;

            padding: 40px;

            min-height: 100vh;

        }


        /* =================================
           HEADER
        ================================= */

        .page-header {

            display: flex;

            justify-content: space-between;

            align-items: center;

            margin-bottom: 30px;

        }


        .page-header h1 {

            margin: 0;

            font-size: 32px;

            color: #123f91;

        }


        .page-header p {

            margin-top: 8px;

            color: #666;

        }


        .back-btn {

            text-decoration: none;

            background: #123f91;

            color: white;

            padding: 12px 18px;

            border-radius: 8px;

            transition: 0.3s;

        }


        .back-btn:hover {

            background: #0b2d6b;

        }


        /* =================================
           STAT CARDS
        ================================= */

        .stats-grid {

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 22px;

            margin-bottom: 30px;

        }


        .stat-card {

            background: white;

            padding: 25px;

            border-radius: 15px;

            box-shadow:
                0 5px 20px
                rgba(0,0,0,0.08);

            display: flex;

            align-items: center;

            gap: 20px;

            transition: 0.3s;

        }


        .stat-card:hover {

            transform: translateY(-4px);

            box-shadow:
                0 10px 25px
                rgba(0,0,0,0.12);

        }


        .stat-icon {

            width: 60px;

            height: 60px;

            border-radius: 12px;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 26px;

            background: #eaf1ff;

            color: #1555b5;

        }


        .stat-info h3 {

            margin: 0;

            font-size: 30px;

            color: #123f91;

        }


        .stat-info p {

            margin: 5px 0 0;

            color: #666;

        }


        /* =================================
           REPORT CARD
        ================================= */

        .report-card {

            background: white;

            padding: 28px;

            border-radius: 15px;

            box-shadow:
                0 5px 20px
                rgba(0,0,0,0.08);

            margin-bottom: 30px;

        }


        .report-card h2 {

            margin-top: 0;

            color: #123f91;

            margin-bottom: 25px;

        }


        /* =================================
           STATUS BARS
        ================================= */

        .status-row {

            margin-bottom: 22px;

        }


        .status-heading {

            display: flex;

            justify-content: space-between;

            margin-bottom: 8px;

        }


        .status-name {

            font-weight: bold;

        }


        .status-count {

            color: #666;

        }


        .progress {

            width: 100%;

            height: 12px;

            background: #edf0f5;

            border-radius: 20px;

            overflow: hidden;

        }


        .progress-bar {

            height: 100%;

            border-radius: 20px;

            background: #1769e0;

        }


        /* =================================
           TABLE
        ================================= */

        .table-wrapper {

            overflow-x: auto;

        }


        table {

            width: 100%;

            border-collapse: collapse;

            min-width: 950px;

        }


        th {

            background: #123f91;

            color: white;

            padding: 14px;

            text-align: left;

        }


        td {

            padding: 13px;

            border-bottom:
                1px solid #eee;

        }


        tbody tr:hover {

            background: #f7f9fd;

        }


        .tracking-number {

            font-weight: bold;

            color: #1769e0;

        }


        /* =================================
           STATUS BADGES
        ================================= */

        .status {

            display: inline-block;

            padding: 6px 12px;

            border-radius: 20px;

            font-size: 13px;

            font-weight: bold;

            white-space: nowrap;

        }


        .booked {

            background: #e8f0ff;

            color: #1555b5;

        }


        .packed {

            background: #fff3cd;

            color: #856404;

        }


        .transit {

            background: #dff3ff;

            color: #006a9e;

        }


        .out {

            background: #eadfff;

            color: #6433a3;

        }


        .delivered {

            background: #dff6e5;

            color: #16803c;

        }


        /* =================================
           EMPTY
        ================================= */

        .empty {

            text-align: center;

            padding: 40px;

            color: #777;

        }


        .empty i {

            font-size: 40px;

            margin-bottom: 15px;

            color: #aaa;

        }


        /* =================================
           MOBILE
        ================================= */

        @media (max-width: 1100px) {

            .stats-grid {

                grid-template-columns:
                    repeat(2, 1fr);

            }

        }


        @media (max-width: 900px) {

            .page-container {

                margin-left: 0;

                padding: 20px;

            }


            .page-header {

                flex-direction: column;

                align-items: flex-start;

                gap: 15px;

            }

        }


        @media (max-width: 600px) {

            .stats-grid {

                grid-template-columns: 1fr;

            }


            .page-header h1 {

                font-size: 26px;

            }

        }

    </style>

</head>


<body>


<div class="page-container">


    <!-- =================================
         HEADER
    ================================= -->

    <div class="page-header">

        <div>

            <h1>

                <i class="fa-solid fa-chart-column"></i>

                Reports

            </h1>

            <p>

                View parcel statistics and delivery reports.

            </p>

        </div>


        <a href="dashboard.php"
           class="back-btn">

            <i class="fa-solid fa-arrow-left"></i>

            Dashboard

        </a>

    </div>



    <!-- =================================
         STATISTICS
    ================================= -->

    <div class="stats-grid">


        <!-- CUSTOMERS -->

        <div class="stat-card">

            <div class="stat-icon">

                <i class="fa-solid fa-users"></i>

            </div>

            <div class="stat-info">

                <h3>
                    <?php echo $totalCustomers; ?>
                </h3>

                <p>
                    Total Customers
                </p>

            </div>

        </div>


        <!-- TOTAL PARCELS -->

        <div class="stat-card">

            <div class="stat-icon">

                <i class="fa-solid fa-box"></i>

            </div>

            <div class="stat-info">

                <h3>
                    <?php echo $totalParcels; ?>
                </h3>

                <p>
                    Total Parcels
                </p>

            </div>

        </div>


        <!-- BOOKED -->

        <div class="stat-card">

            <div class="stat-icon">

                <i class="fa-solid fa-clipboard-check"></i>

            </div>

            <div class="stat-info">

                <h3>
                    <?php echo $booked; ?>
                </h3>

                <p>
                    Booked
                </p>

            </div>

        </div>


        <!-- PACKED -->

        <div class="stat-card">

            <div class="stat-icon">

                <i class="fa-solid fa-box-open"></i>

            </div>

            <div class="stat-info">

                <h3>
                    <?php echo $packed; ?>
                </h3>

                <p>
                    Packed
                </p>

            </div>

        </div>


        <!-- IN TRANSIT -->

        <div class="stat-card">

            <div class="stat-icon">

                <i class="fa-solid fa-truck"></i>

            </div>

            <div class="stat-info">

                <h3>
                    <?php echo $inTransit; ?>
                </h3>

                <p>
                    In Transit
                </p>

            </div>

        </div>


        <!-- DELIVERED -->

        <div class="stat-card">

            <div class="stat-icon">

                <i class="fa-solid fa-circle-check"></i>

            </div>

            <div class="stat-info">

                <h3>
                    <?php echo $delivered; ?>
                </h3>

                <p>
                    Delivered
                </p>

            </div>

        </div>


    </div>



    <!-- =================================
         STATUS REPORT
    ================================= -->

    <div class="report-card">

        <h2>

            <i class="fa-solid fa-chart-simple"></i>

            Parcel Status Overview

        </h2>


        <!-- BOOKED -->

        <div class="status-row">

            <div class="status-heading">

                <span class="status-name">
                    Booked
                </span>

                <span class="status-count">
                    <?php echo $booked; ?>
                    (<?php echo $bookedPercent; ?>%)
                </span>

            </div>

            <div class="progress">

                <div class="progress-bar"
                     style="width: <?php echo $bookedPercent; ?>%;">
                </div>

            </div>

        </div>


        <!-- PACKED -->

        <div class="status-row">

            <div class="status-heading">

                <span class="status-name">
                    Packed
                </span>

                <span class="status-count">
                    <?php echo $packed; ?>
                    (<?php echo $packedPercent; ?>%)
                </span>

            </div>

            <div class="progress">

                <div class="progress-bar"
                     style="width: <?php echo $packedPercent; ?>%;">
                </div>

            </div>

        </div>


        <!-- IN TRANSIT -->

        <div class="status-row">

            <div class="status-heading">

                <span class="status-name">
                    In Transit
                </span>

                <span class="status-count">
                    <?php echo $inTransit; ?>
                    (<?php echo $transitPercent; ?>%)
                </span>

            </div>

            <div class="progress">

                <div class="progress-bar"
                     style="width: <?php echo $transitPercent; ?>%;">
                </div>

            </div>

        </div>


        <!-- OUT FOR DELIVERY -->

        <div class="status-row">

            <div class="status-heading">

                <span class="status-name">
                    Out for Delivery
                </span>

                <span class="status-count">
                    <?php echo $outForDelivery; ?>
                    (<?php echo $outPercent; ?>%)
                </span>

            </div>

            <div class="progress">

                <div class="progress-bar"
                     style="width: <?php echo $outPercent; ?>%;">
                </div>

            </div>

        </div>


        <!-- DELIVERED -->

        <div class="status-row">

            <div class="status-heading">

                <span class="status-name">
                    Delivered
                </span>

                <span class="status-count">
                    <?php echo $delivered; ?>
                    (<?php echo $deliveredPercent; ?>%)
                </span>

            </div>

            <div class="progress">

                <div class="progress-bar"
                     style="width: <?php echo $deliveredPercent; ?>%;">
                </div>

            </div>

        </div>


    </div>



    <!-- =================================
         RECENT PARCELS
    ================================= -->

    <div class="report-card">

        <h2>

            <i class="fa-solid fa-clock-rotate-left"></i>

            Recent Parcels

        </h2>


        <div class="table-wrapper">


            <?php if (
                $recentParcels &&
                mysqli_num_rows($recentParcels) > 0
            ): ?>


                <table>

                    <thead>

                        <tr>

                            <th>
                                Tracking Number
                            </th>

                            <th>
                                Sender
                            </th>

                            <th>
                                Receiver
                            </th>

                            <th>
                                Parcel Type
                            </th>

                            <th>
                                Weight
                            </th>

                            <th>
                                Booking Date
                            </th>

                            <th>
                                Status
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                    <?php while (
                        $row =
                        mysqli_fetch_assoc(
                            $recentParcels
                        )
                    ): ?>


                        <?php

                        $statusClass = "booked";

                        if (
                            $row['status']
                            == "Packed"
                        ) {

                            $statusClass =
                                "packed";

                        }
                        elseif (
                            $row['status']
                            == "In Transit"
                        ) {

                            $statusClass =
                                "transit";

                        }
                        elseif (
                            $row['status']
                            == "Out for Delivery"
                        ) {

                            $statusClass =
                                "out";

                        }
                        elseif (
                            $row['status']
                            == "Delivered"
                        ) {

                            $statusClass =
                                "delivered";

                        }

                        ?>


                        <tr>


                            <td>

                                <span class="tracking-number">

                                    <i class="fa-solid fa-box"></i>

                                    <?php

                                    echo htmlspecialchars(
                                        $row[
                                            'tracking_number'
                                        ]
                                    );

                                    ?>

                                </span>

                            </td>


                            <td>

                                <?php

                                echo htmlspecialchars(
                                    $row[
                                        'sender_name'
                                    ]
                                    ?? 'N/A'
                                );

                                ?>

                            </td>


                            <td>

                                <?php

                                echo htmlspecialchars(
                                    $row[
                                        'receiver_name'
                                    ]
                                );

                                ?>

                            </td>


                            <td>

                                <?php

                                echo htmlspecialchars(
                                    $row[
                                        'parcel_type'
                                    ]
                                );

                                ?>

                            </td>


                            <td>

                                <?php

                                echo htmlspecialchars(
                                    $row[
                                        'weight'
                                    ]
                                );

                                ?>

                                kg

                            </td>


                            <td>

                                <?php

                                echo date(
                                    "d M Y",
                                    strtotime(
                                        $row[
                                            'booking_date'
                                        ]
                                    )
                                );

                                ?>

                            </td>


                            <td>

                                <span class="status <?php echo $statusClass; ?>">

                                    <?php

                                    echo htmlspecialchars(
                                        $row[
                                            'status'
                                        ]
                                    );

                                    ?>

                                </span>

                            </td>


                        </tr>


                    <?php endwhile; ?>


                    </tbody>

                </table>


            <?php else: ?>


                <div class="empty">

                    <i class="fa-solid fa-box-open"></i>

                    <h3>
                        No Parcels Found
                    </h3>

                    <p>
                        Parcel reports will appear here after parcels are booked.
                    </p>

                </div>


            <?php endif; ?>


        </div>

    </div>


</div>


</body>

</html>