<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include("../includes/db.php");

$message = "";
$error = "";

/* ---------------------------------------------------
   UPDATE TRACKING
--------------------------------------------------- */

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $parcel_id = intval($_POST['parcel_id']);
    $location  = trim($_POST['location']);
    $status    = trim($_POST['status']);
    $remarks   = trim($_POST['remarks']);

    if ($parcel_id <= 0 || empty($location) || empty($status)) {

        $error = "Please fill all required fields.";

    } else {

        /* Start transaction */
        mysqli_begin_transaction($conn);

        try {

            /* -----------------------------------------
               1. Insert new tracking record
            ----------------------------------------- */

            $stmt = mysqli_prepare(
                $conn,
                "INSERT INTO tracking
                (parcel_id, location, status, remarks, updated_at)
                VALUES (?, ?, ?, ?, NOW())"
            );

            mysqli_stmt_bind_param(
                $stmt,
                "isss",
                $parcel_id,
                $location,
                $status,
                $remarks
            );

            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception("Unable to add tracking record.");
            }

            mysqli_stmt_close($stmt);


            /* -----------------------------------------
               2. Update parcel current status
            ----------------------------------------- */

            $stmt2 = mysqli_prepare(
                $conn,
                "UPDATE parcel
                 SET status = ?
                 WHERE parcel_id = ?"
            );

            mysqli_stmt_bind_param(
                $stmt2,
                "si",
                $status,
                $parcel_id
            );

            if (!mysqli_stmt_execute($stmt2)) {
                throw new Exception("Unable to update parcel status.");
            }

            mysqli_stmt_close($stmt2);


            /* Commit */
            mysqli_commit($conn);

            $message = "Tracking status updated successfully.";

        } catch (Exception $e) {

            mysqli_rollback($conn);

            $error = $e->getMessage();
        }
    }
}


/* ---------------------------------------------------
   GET ALL PARCELS
--------------------------------------------------- */

$parcels = mysqli_query(
    $conn,
    "SELECT
        p.parcel_id,
        p.tracking_number,
        p.receiver_name,
        p.status,
        c.full_name AS sender_name
     FROM parcel p
     LEFT JOIN customer c
        ON p.customer_id = c.customer_id
     ORDER BY p.parcel_id DESC"
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Update Tracking | Keystone Cargo</title>

    <link rel="stylesheet"
          href="../assets/css/admin.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f7fc;
            color: #222;
        }

        .page-container {
            margin-left: 270px;
            padding: 40px;
            min-height: 100vh;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h1 {
            margin: 0;
            font-size: 32px;
            color: #123f91;
        }

        .page-header p {
            margin-top: 8px;
            color: #666;
        }

        .back-btn {
            text-decoration: none;
            background: #123f91;
            color: white;
            padding: 12px 18px;
            border-radius: 8px;
            transition: 0.3s;
        }

        .back-btn:hover {
            background: #0b2d6b;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            max-width: 850px;
            margin-bottom: 30px;
        }

        .card h2 {
            margin-top: 0;
            color: #123f91;
            margin-bottom: 25px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: #333;
        }

        .form-group label span {
            color: red;
        }

        .form-group select,
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 13px 15px;
            border: 1px solid #d4dbe8;
            border-radius: 8px;
            font-size: 15px;
            outline: none;
            transition: 0.3s;
            background: white;
        }

        .form-group select:focus,
        .form-group input:focus,
        .form-group textarea:focus {
            border-color: #1769e0;
            box-shadow: 0 0 0 3px rgba(23,105,224,0.1);
        }

        .form-group textarea {
            min-height: 110px;
            resize: vertical;
        }

        .parcel-info {
            background: #f4f7ff;
            border-left: 5px solid #1769e0;
            padding: 15px 18px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: none;
        }

        .parcel-info strong {
            color: #123f91;
        }

        .submit-btn {
            border: none;
            background: #1769e0;
            color: white;
            padding: 14px 25px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        .submit-btn:hover {
            background: #0d4fb5;
            transform: translateY(-2px);
        }

        .success {
            max-width: 850px;
            background: #dff6e5;
            color: #176b35;
            border-left: 5px solid #28a745;
            padding: 15px 18px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .error {
            max-width: 850px;
            background: #ffe0e0;
            color: #a30000;
            border-left: 5px solid #dc3545;
            padding: 15px 18px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .table-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            overflow-x: auto;
        }

        .table-card h2 {
            color: #123f91;
            margin-top: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th {
            background: #123f91;
            color: white;
            padding: 14px;
            text-align: left;
        }

        td {
            padding: 13px;
            border-bottom: 1px solid #eee;
        }

        tr:hover {
            background: #f7f9fd;
        }

        .status {
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
            display: inline-block;
        }

        .booked {
            background: #e8f0ff;
            color: #1555b5;
        }

        .packed {
            background: #fff3cd;
            color: #856404;
        }

        .transit {
            background: #dff3ff;
            color: #006a9e;
        }

        .out {
            background: #e9dfff;
            color: #6433a3;
        }

        .delivered {
            background: #dff6e5;
            color: #16803c;
        }

        @media (max-width: 900px) {

            .page-container {
                margin-left: 0;
                padding: 20px;
            }

            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

        }

    </style>

</head>

<body>


<?php
/*
   If your dashboard already has a sidebar,
   this page can use the same sidebar.
*/
?>

<div class="page-container">

    <div class="page-header">

        <div>
            <h1>
                <i class="fa-solid fa-location-dot"></i>
                Update Tracking
            </h1>

            <p>
                Update the current location and delivery status of a parcel.
            </p>
        </div>

        <a href="dashboard.php" class="back-btn">
            <i class="fa-solid fa-arrow-left"></i>
            Dashboard
        </a>

    </div>


    <?php if (!empty($message)): ?>

        <div class="success">
            <i class="fa-solid fa-circle-check"></i>
            <?php echo htmlspecialchars($message); ?>
        </div>

    <?php endif; ?>


    <?php if (!empty($error)): ?>

        <div class="error">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?php echo htmlspecialchars($error); ?>
        </div>

    <?php endif; ?>


    <!-- UPDATE FORM -->

    <div class="card">

        <h2>
            <i class="fa-solid fa-truck-fast"></i>
            Add Tracking Update
        </h2>


        <form method="POST"
              action="">


            <!-- PARCEL -->

            <div class="form-group">

                <label>
                    Select Parcel <span>*</span>
                </label>

                <select name="parcel_id"
                        id="parcel_id"
                        required
                        onchange="showParcelInfo()">

                    <option value="">
                        -- Select Parcel --
                    </option>

                    <?php while ($parcel = mysqli_fetch_assoc($parcels)): ?>

                        <option
                            value="<?php echo $parcel['parcel_id']; ?>"
                            data-tracking="<?php echo htmlspecialchars($parcel['tracking_number']); ?>"
                            data-receiver="<?php echo htmlspecialchars($parcel['receiver_name']); ?>"
                            data-sender="<?php echo htmlspecialchars($parcel['sender_name'] ?? 'N/A'); ?>"
                            data-status="<?php echo htmlspecialchars($parcel['status']); ?>"
                        >

                            <?php echo htmlspecialchars($parcel['tracking_number']); ?>
                            -
                            <?php echo htmlspecialchars($parcel['receiver_name']); ?>

                        </option>

                    <?php endwhile; ?>

                </select>

            </div>


            <!-- PARCEL INFORMATION -->

            <div class="parcel-info" id="parcelInfo">

                <div>
                    <strong>Tracking Number:</strong>
                    <span id="trackingDisplay"></span>
                </div>

                <div>
                    <strong>Sender:</strong>
                    <span id="senderDisplay"></span>
                </div>

                <div>
                    <strong>Receiver:</strong>
                    <span id="receiverDisplay"></span>
                </div>

                <div>
                    <strong>Current Status:</strong>
                    <span id="currentStatusDisplay"></span>
                </div>

            </div>


            <!-- LOCATION -->

            <div class="form-group">

                <label>
                    Current Location <span>*</span>
                </label>

                <input
                    type="text"
                    name="location"
                    placeholder="Example: Vijayawada Hub"
                    maxlength="150"
                    required
                >

            </div>


            <!-- STATUS -->

            <div class="form-group">

                <label>
                    Parcel Status <span>*</span>
                </label>

                <select name="status" required>

                    <option value="">
                        -- Select Status --
                    </option>

                    <option value="Booked">
                        Booked
                    </option>

                    <option value="Packed">
                        Packed
                    </option>

                    <option value="In Transit">
                        In Transit
                    </option>

                    <option value="Out for Delivery">
                        Out for Delivery
                    </option>

                    <option value="Delivered">
                        Delivered
                    </option>

                </select>

            </div>


            <!-- REMARKS -->

            <div class="form-group">

                <label>
                    Remarks
                </label>

                <textarea
                    name="remarks"
                    placeholder="Enter any additional information..."
                ></textarea>

            </div>


            <!-- SUBMIT -->

            <button type="submit"
                    class="submit-btn">

                <i class="fa-solid fa-location-arrow"></i>
                Update Tracking

            </button>

        </form>

    </div>



    <!-- PARCEL LIST -->

    <div class="table-card">

        <h2>
            <i class="fa-solid fa-box"></i>
            Current Parcels
        </h2>

        <table>

            <thead>

                <tr>
                    <th>Tracking Number</th>
                    <th>Sender</th>
                    <th>Receiver</th>
                    <th>Current Status</th>
                </tr>

            </thead>

            <tbody>

                <?php

                mysqli_data_seek(
                    $parcels,
                    0
                );

                while ($parcel = mysqli_fetch_assoc($parcels)):

                    $statusClass = "";

                    if ($parcel['status'] == "Booked") {
                        $statusClass = "booked";
                    }
                    elseif ($parcel['status'] == "Packed") {
                        $statusClass = "packed";
                    }
                    elseif ($parcel['status'] == "In Transit") {
                        $statusClass = "transit";
                    }
                    elseif ($parcel['status'] == "Out for Delivery") {
                        $statusClass = "out";
                    }
                    elseif ($parcel['status'] == "Delivered") {
                        $statusClass = "delivered";
                    }

                ?>

                    <tr>

                        <td>
                            <strong>
                                <?php
                                echo htmlspecialchars(
                                    $parcel['tracking_number']
                                );
                                ?>
                            </strong>
                        </td>

                        <td>
                            <?php
                            echo htmlspecialchars(
                                $parcel['sender_name'] ?? 'N/A'
                            );
                            ?>
                        </td>

                        <td>
                            <?php
                            echo htmlspecialchars(
                                $parcel['receiver_name']
                            );
                            ?>
                        </td>

                        <td>

                            <span class="status <?php echo $statusClass; ?>">

                                <?php
                                echo htmlspecialchars(
                                    $parcel['status']
                                );
                                ?>

                            </span>

                        </td>

                    </tr>

                <?php endwhile; ?>

            </tbody>

        </table>

    </div>

</div>


<script>

function showParcelInfo() {

    const select = document.getElementById("parcel_id");

    const info = document.getElementById("parcelInfo");

    const option = select.options[select.selectedIndex];


    if (select.value === "") {

        info.style.display = "none";

        return;
    }


    document.getElementById("trackingDisplay").textContent =
        option.getAttribute("data-tracking");

    document.getElementById("senderDisplay").textContent =
        option.getAttribute("data-sender");

    document.getElementById("receiverDisplay").textContent =
        option.getAttribute("data-receiver");

    document.getElementById("currentStatusDisplay").textContent =
        option.getAttribute("data-status");


    info.style.display = "block";

}

</script>


</body>

</html>