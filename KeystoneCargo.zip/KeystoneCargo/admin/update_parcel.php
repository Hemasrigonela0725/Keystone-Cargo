<?php
session_start();

include("../includes/db.php");

/* Check admin login */
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}


/* =========================
   CHECK PARCEL ID
========================= */

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: view_parcel.php");
    exit();
}

$parcel_id = intval($_GET['id']);


/* =========================
   FETCH PARCEL
========================= */

$sql = "SELECT
            p.*,
            c.full_name AS sender_name
        FROM parcel p
        LEFT JOIN customer c
            ON p.customer_id = c.customer_id
        WHERE p.parcel_id = ?";

$stmt = mysqli_prepare($conn, $sql);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $parcel_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {

    mysqli_stmt_close($stmt);

    header("Location: view_parcel.php");
    exit();
}

$parcel = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);


$error = "";


/* =========================
   UPDATE STATUS
========================= */

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $new_status = trim($_POST['status']);
    $location = trim($_POST['location']);
    $remarks = trim($_POST['remarks']);


    $allowed_statuses = [
        "Booked",
        "Packed",
        "In Transit",
        "Out for Delivery",
        "Delivered"
    ];


    /* Validate status */

    if (!in_array($new_status, $allowed_statuses)) {

        $error = "Invalid parcel status.";

    } elseif ($location == "") {

        $error = "Please enter the current location.";

    } else {


        /* =========================
           UPDATE PARCEL STATUS
        ========================= */

        $update_sql = "UPDATE parcel
                       SET status = ?
                       WHERE parcel_id = ?";

        $update_stmt = mysqli_prepare(
            $conn,
            $update_sql
        );

        mysqli_stmt_bind_param(
            $update_stmt,
            "si",
            $new_status,
            $parcel_id
        );


        if (mysqli_stmt_execute($update_stmt)) {

            mysqli_stmt_close($update_stmt);


            /* =========================
               ADD TRACKING HISTORY
            ========================= */

            $history_sql = "INSERT INTO tracking_history
            (
                parcel_id,
                status,
                location,
                remarks,
                updated_at
            )
            VALUES
            (?, ?, ?, ?, NOW())";


            $history_stmt = mysqli_prepare(
                $conn,
                $history_sql
            );


            if ($history_stmt) {

                mysqli_stmt_bind_param(
                    $history_stmt,
                    "isss",
                    $parcel_id,
                    $new_status,
                    $location,
                    $remarks
                );

                mysqli_stmt_execute(
                    $history_stmt
                );

                mysqli_stmt_close(
                    $history_stmt
                );
            }


            /* Return to parcel list */

            header(
                "Location: view_parcel.php?updated=1"
            );

            exit();


        } else {

            $error =
                "Unable to update parcel status.";

            mysqli_stmt_close(
                $update_stmt
            );
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Update Parcel | Keystone Cargo</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial,sans-serif;
}

body{
    background:#f4f7fc;
    color:#102a56;
}


/* ================= NAVBAR ================= */

.navbar{
    height:80px;
    background:linear-gradient(
        90deg,
        #0d3b82,
        #1269ed
    );

    display:flex;
    align-items:center;
    padding:0 5%;

    color:white;
}

.logo{
    display:flex;
    align-items:center;
    gap:12px;
}

.logo i{
    font-size:30px;
    color:#ffc107;
}

.logo h2{
    font-size:25px;
}

.nav-right{
    margin-left:auto;

    display:flex;
    align-items:center;

    gap:25px;
}

.nav-right a{
    color:white;
    text-decoration:none;

    font-size:16px;
}

.nav-right a:hover{
    color:#ffc107;
}


/* ================= CONTAINER ================= */

.container{
    width:92%;
    max-width:900px;

    margin:45px auto;
}


/* ================= CARD ================= */

.card{
    background:white;

    padding:40px;

    border-radius:20px;

    box-shadow:
        0 12px 35px
        rgba(0,0,0,0.08);
}


/* ================= TITLE ================= */

.title{
    text-align:center;

    margin-bottom:30px;
}

.title h1{
    font-size:36px;

    color:#102a56;
}

.title h1 i{
    color:#1269ed;
}

.title p{
    margin-top:8px;

    color:#777;
}


/* ================= PARCEL INFO ================= */

.parcel-info{
    background:#f5f8fd;

    padding:25px;

    border-radius:15px;

    margin-bottom:30px;
}

.info-row{
    display:grid;

    grid-template-columns:1fr 1fr;

    gap:20px;
}

.info-item{
    padding:5px;
}

.info-label{
    font-size:14px;

    color:#777;

    margin-bottom:6px;
}

.info-value{
    font-size:18px;

    font-weight:bold;

    color:#102a56;
}

.tracking{
    color:#1269ed;
}


/* ================= FORM ================= */

.form-group{
    margin-bottom:22px;
}

.form-group label{
    display:block;

    font-weight:bold;

    margin-bottom:8px;
}

.form-group select,
.form-group input,
.form-group textarea{

    width:100%;

    padding:14px 16px;

    border:1px solid #d5deeb;

    border-radius:10px;

    font-size:16px;

    outline:none;

    background:white;
}

.form-group select:focus,
.form-group input:focus,
.form-group textarea:focus{

    border-color:#1269ed;

    box-shadow:
        0 0 0 3px
        rgba(18,105,237,0.10);
}

.form-group textarea{

    min-height:110px;

    resize:vertical;
}


/* ================= ERROR ================= */

.error{

    background:#ffe0e0;

    color:#9b1c1c;

    border:1px solid #ffb3b3;

    padding:15px;

    border-radius:10px;

    margin-bottom:25px;

    text-align:center;
}


/* ================= BUTTONS ================= */

.buttons{

    display:flex;

    gap:15px;

    margin-top:10px;
}

.btn{

    flex:1;

    padding:16px;

    border:none;

    border-radius:10px;

    font-size:17px;

    font-weight:bold;

    cursor:pointer;

    text-decoration:none;

    text-align:center;
}

.update-btn{

    background:#1269ed;

    color:white;
}

.update-btn:hover{

    background:#0d56c7;
}

.cancel-btn{

    background:#e9edf3;

    color:#333;
}

.cancel-btn:hover{

    background:#dce2ea;
}


/* ================= RESPONSIVE ================= */

@media(max-width:700px){

    .navbar{

        height:auto;

        padding:18px 20px;

        flex-direction:column;

        gap:15px;
    }

    .nav-right{

        margin-left:0;

        flex-wrap:wrap;

        justify-content:center;
    }

    .card{

        padding:25px;
    }

    .info-row{

        grid-template-columns:1fr;
    }

    .buttons{

        flex-direction:column;
    }

}

</style>

</head>


<body>


<!-- ================= NAVBAR ================= -->

<nav class="navbar">


    <div class="logo">

        <i class="fa-solid fa-truck-fast"></i>

        <h2>
            Keystone Cargo
        </h2>

    </div>


    <div class="nav-right">

        <a href="dashboard.php">

            <i class="fa-solid fa-gauge"></i>

            Dashboard

        </a>


        <a href="view_parcel.php">

            <i class="fa-solid fa-boxes-stacked"></i>

            Parcels

        </a>


        <a href="logout.php">

            <i class="fa-solid fa-right-from-bracket"></i>

            Logout

        </a>

    </div>

</nav>


<!-- ================= MAIN ================= -->

<div class="container">


    <div class="card">


        <div class="title">

            <h1>

                <i class="fa-solid fa-truck-fast"></i>

                Update Parcel

            </h1>

            <p>
                Update the current delivery status
            </p>

        </div>


        <!-- ================= PARCEL INFORMATION ================= -->

        <div class="parcel-info">


            <div class="info-row">


                <div class="info-item">

                    <div class="info-label">
                        Tracking Number
                    </div>

                    <div class="info-value tracking">

                        <?php
                        echo htmlspecialchars(
                            $parcel['tracking_number']
                        );
                        ?>

                    </div>

                </div>


                <div class="info-item">

                    <div class="info-label">
                        Sender
                    </div>

                    <div class="info-value">

                        <?php

                        echo !empty(
                            $parcel['sender_name']
                        )
                        ?
                        htmlspecialchars(
                            $parcel['sender_name']
                        )
                        :
                        "N/A";

                        ?>

                    </div>

                </div>


                <div class="info-item">

                    <div class="info-label">
                        Receiver
                    </div>

                    <div class="info-value">

                        <?php
                        echo htmlspecialchars(
                            $parcel['receiver_name']
                        );
                        ?>

                    </div>

                </div>


                <div class="info-item">

                    <div class="info-label">
                        Current Status
                    </div>

                    <div class="info-value">

                        <?php
                        echo htmlspecialchars(
                            $parcel['status']
                        );
                        ?>

                    </div>

                </div>

            </div>

        </div>


        <?php if ($error != ""): ?>

            <div class="error">

                <i class="fa-solid fa-circle-exclamation"></i>

                <?php
                echo htmlspecialchars($error);
                ?>

            </div>

        <?php endif; ?>


        <!-- ================= UPDATE FORM ================= -->

        <form method="POST">


            <!-- STATUS -->

            <div class="form-group">

                <label>

                    Parcel Status

                </label>


                <select
                    name="status"
                    required>


                    <option
                        value="Booked"
                        <?php
                        if (
                            $parcel['status']
                            ==
                            'Booked'
                        ) echo 'selected';
                        ?>>

                        Booked

                    </option>


                    <option
                        value="Packed"
                        <?php
                        if (
                            $parcel['status']
                            ==
                            'Packed'
                        ) echo 'selected';
                        ?>>

                        Packed

                    </option>


                    <option
                        value="In Transit"
                        <?php
                        if (
                            $parcel['status']
                            ==
                            'In Transit'
                        ) echo 'selected';
                        ?>>

                        In Transit

                    </option>


                    <option
                        value="Out for Delivery"
                        <?php
                        if (
                            $parcel['status']
                            ==
                            'Out for Delivery'
                        ) echo 'selected';
                        ?>>

                        Out for Delivery

                    </option>


                    <option
                        value="Delivered"
                        <?php
                        if (
                            $parcel['status']
                            ==
                            'Delivered'
                        ) echo 'selected';
                        ?>>

                        Delivered

                    </option>


                </select>

            </div>


            <!-- LOCATION -->

            <div class="form-group">

                <label>

                    Current Location

                </label>

                <input
                    type="text"
                    name="location"
                    placeholder="Example: Hyderabad Hub"
                    required>

            </div>


            <!-- REMARKS -->

            <div class="form-group">

                <label>

                    Remarks

                </label>

                <textarea
                    name="remarks"
                    placeholder="Enter any additional information about this update"></textarea>

            </div>


            <!-- BUTTONS -->

            <div class="buttons">


                <button
                    type="submit"
                    class="btn update-btn">

                    <i class="fa-solid fa-floppy-disk"></i>

                    Update Status

                </button>


                <a
                    href="view_parcel.php"
                    class="btn cancel-btn">

                    <i class="fa-solid fa-xmark"></i>

                    Cancel

                </a>


            </div>


        </form>


    </div>

</div>

</body>

</html>