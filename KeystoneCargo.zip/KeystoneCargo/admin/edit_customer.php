<?php
session_start();

include("../includes/db.php");

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: view_customer.php");
    exit();
}

$customer_id = intval($_GET['id']);

$sql = "SELECT * FROM customer WHERE customer_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $customer_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    header("Location: view_customer.php");
    exit();
}

$customer = mysqli_fetch_assoc($result);

mysqli_stmt_close($stmt);

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);

    if ($full_name == "" || $phone == "" || $email == "" || $address == "") {

        $error = "Please fill in all fields.";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $error = "Please enter a valid email address.";

    } else {

        $update_sql = "UPDATE customer 
                       SET full_name = ?,
                           phone = ?,
                           email = ?,
                           address = ?
                       WHERE customer_id = ?";

        $update_stmt = mysqli_prepare($conn, $update_sql);

        mysqli_stmt_bind_param(
            $update_stmt,
            "ssssi",
            $full_name,
            $phone,
            $email,
            $address,
            $customer_id
        );

        if (mysqli_stmt_execute($update_stmt)) {

            header("Location: view_customer.php?updated=1");
            exit();

        } else {

            $error = "Unable to update customer.";
        }

        mysqli_stmt_close($update_stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Edit Customer | Keystone Cargo</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial, sans-serif;
}

body{
    background:#f4f7fc;
    color:#102a56;
}

/* NAVBAR */

.navbar{
    background:linear-gradient(90deg,#0d3b82,#1269ed);
    height:80px;
    display:flex;
    align-items:center;
    padding:0 40px;
    color:white;
}

.navbar h2{
    font-size:26px;
}

.navbar a{
    margin-left:auto;
    color:white;
    text-decoration:none;
    font-size:17px;
}

.navbar a:hover{
    color:#ffc107;
}

/* CONTAINER */

.container{
    width:90%;
    max-width:850px;
    margin:50px auto;
}

/* CARD */

.card{
    background:white;
    padding:40px;
    border-radius:20px;
    box-shadow:0 12px 35px rgba(0,0,0,0.10);
}

.title{
    text-align:center;
    margin-bottom:30px;
}

.title h1{
    font-size:34px;
    color:#102a56;
}

.title p{
    margin-top:8px;
    color:#777;
}

/* FORM */

.form-group{
    margin-bottom:20px;
}

.form-group label{
    display:block;
    font-weight:bold;
    margin-bottom:8px;
    color:#102a56;
}

.form-group input,
.form-group textarea{
    width:100%;
    padding:14px 16px;
    border:1px solid #d5deeb;
    border-radius:10px;
    font-size:16px;
    outline:none;
}

.form-group input:focus,
.form-group textarea:focus{
    border-color:#1269ed;
    box-shadow:0 0 0 3px rgba(18,105,237,0.10);
}

textarea{
    min-height:120px;
    resize:vertical;
}

/* BUTTONS */

.buttons{
    display:flex;
    gap:15px;
    margin-top:25px;
}

.btn{
    flex:1;
    padding:15px;
    border:none;
    border-radius:10px;
    font-size:17px;
    font-weight:bold;
    cursor:pointer;
    text-align:center;
    text-decoration:none;
}

.update-btn{
    background:#1269ed;
    color:white;
}

.update-btn:hover{
    background:#0d56c7;
}

.cancel-btn{
    background:#e9edf3;
    color:#333;
}

.cancel-btn:hover{
    background:#dce2ea;
}

/* MESSAGES */

.error{
    background:#ffe0e0;
    color:#9b1c1c;
    padding:14px;
    border-radius:10px;
    margin-bottom:20px;
    text-align:center;
}

@media(max-width:600px){

    .container{
        width:95%;
    }

    .card{
        padding:25px;
    }

    .buttons{
        flex-direction:column;
    }

}

</style>

</head>

<body>

<!-- NAVBAR -->

<div class="navbar">

    <h2>
        <i class="fa-solid fa-truck-fast"></i>
        Keystone Cargo
    </h2>

    <a href="dashboard.php">
        <i class="fa-solid fa-arrow-left"></i>
        Dashboard
    </a>

</div>


<!-- MAIN -->

<div class="container">

    <div class="card">

        <div class="title">

            <h1>
                <i class="fa-solid fa-user-pen"></i>
                Edit Customer
            </h1>

            <p>
                Update the customer's information
            </p>

        </div>


        <?php if ($error != ""): ?>

            <div class="error">

                <i class="fa-solid fa-circle-exclamation"></i>

                <?php echo htmlspecialchars($error); ?>

            </div>

        <?php endif; ?>


        <form method="POST">


            <!-- NAME -->

            <div class="form-group">

                <label>
                    Full Name
                </label>

                <input
                    type="text"
                    name="full_name"
                    value="<?php echo htmlspecialchars($customer['full_name']); ?>"
                    required
                >

            </div>


            <!-- PHONE -->

            <div class="form-group">

                <label>
                    Phone Number
                </label>

                <input
                    type="text"
                    name="phone"
                    value="<?php echo htmlspecialchars($customer['phone']); ?>"
                    required
                >

            </div>


            <!-- EMAIL -->

            <div class="form-group">

                <label>
                    Email Address
                </label>

                <input
                    type="email"
                    name="email"
                    value="<?php echo htmlspecialchars($customer['email']); ?>"
                    required
                >

            </div>


            <!-- ADDRESS -->

            <div class="form-group">

                <label>
                    Address
                </label>

                <textarea
                    name="address"
                    required
                ><?php echo htmlspecialchars($customer['address']); ?></textarea>

            </div>


            <!-- BUTTONS -->

            <div class="buttons">

                <button
                    type="submit"
                    class="btn update-btn">

                    <i class="fa-solid fa-floppy-disk"></i>
                    Update Customer

                </button>

                <a
                    href="view_customer.php"
                    class="btn cancel-btn">

                    <i class="fa-solid fa-xmark"></i>
                    Cancel

                </a>

            </div>

        </form>

    </div>

</div>

</body>

</html>