<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include("../includes/db.php");


/* -----------------------------------------
   GET TRACKING HISTORY
----------------------------------------- */

$sql = "
    SELECT
        t.tracking_id,
        t.parcel_id,
        t.location,
        t.status,
        t.remarks,
        t.updated_at,
        p.tracking_number,
        p.receiver_name,
        c.full_name AS sender_name
    FROM tracking t
    INNER JOIN parcel p
        ON t.parcel_id = p.parcel_id
    LEFT JOIN customer c
        ON p.customer_id = c.customer_id
    ORDER BY t.updated_at DESC
";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Database Error: " . mysqli_error($conn));
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Tracking History | Keystone Cargo</title>

    <link rel="stylesheet"
          href="../assets/css/admin.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f7fc;
            color: #222;
        }

        .page-container {
            margin-left: 270px;
            padding: 40px;
            min-height: 100vh;
        }

        /* HEADER */

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .page-header h1 {
            margin: 0;
            color: #123f91;
            font-size: 32px;
        }

        .page-header p {
            margin-top: 8px;
            color: #666;
        }

        .back-btn {
            text-decoration: none;
            background: #123f91;
            color: white;
            padding: 12px 18px;
            border-radius: 8px;
            transition: 0.3s;
        }

        .back-btn:hover {
            background: #0b2d6b;
        }

        /* CARD */

        .history-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }

        .history-card h2 {
            margin-top: 0;
            color: #123f91;
            margin-bottom: 20px;
        }

        /* TABLE */

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1000px;
        }

        th {
            background: #123f91;
            color: white;
            padding: 14px;
            text-align: left;
            white-space: nowrap;
        }

        td {
            padding: 14px;
            border-bottom: 1px solid #e5e5e5;
            vertical-align: middle;
        }

        tbody tr {
            transition: 0.2s;
        }

        tbody tr:hover {
            background: #f5f8ff;
        }

        /* TRACKING NUMBER */

        .tracking-number {
            font-weight: bold;
            color: #1769e0;
        }

        /* STATUS */

        .status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
            white-space: nowrap;
        }

        .booked {
            background: #e8f0ff;
            color: #1555b5;
        }

        .packed {
            background: #fff3cd;
            color: #856404;
        }

        .transit {
            background: #dff3ff;
            color: #006a9e;
        }

        .out {
            background: #eadfff;
            color: #6433a3;
        }

        .delivered {
            background: #dff6e5;
            color: #16803c;
        }

        /* LOCATION */

        .location {
            font-weight: 600;
            color: #333;
        }

        /* REMARKS */

        .remarks {
            max-width: 250px;
            color: #666;
        }

        /* DATE */

        .date {
            white-space: nowrap;
            color: #555;
        }

        /* EMPTY */

        .empty {
            text-align: center;
            padding: 50px 20px;
            color: #777;
        }

        .empty i {
            font-size: 45px;
            color: #aaa;
            margin-bottom: 15px;
        }

        .empty h3 {
            margin: 10px 0;
            color: #555;
        }

        /* MOBILE */

        @media (max-width: 900px) {

            .page-container {
                margin-left: 0;
                padding: 20px;
            }

            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .page-header h1 {
                font-size: 26px;
            }

        }

    </style>

</head>


<body>


<div class="page-container">


    <!-- HEADER -->

    <div class="page-header">

        <div>

            <h1>
                <i class="fa-solid fa-clock-rotate-left"></i>
                Tracking History
            </h1>

            <p>
                View the complete movement and status history of parcels.
            </p>

        </div>


        <a href="dashboard.php"
           class="back-btn">

            <i class="fa-solid fa-arrow-left"></i>
            Dashboard

        </a>

    </div>


    <!-- HISTORY CARD -->

    <div class="history-card">

        <h2>
            <i class="fa-solid fa-route"></i>
            Parcel Tracking Updates
        </h2>


        <div class="table-wrapper">

            <?php if (mysqli_num_rows($result) > 0): ?>

                <table>

                    <thead>

                        <tr>

                            <th>#</th>

                            <th>
                                Tracking Number
                            </th>

                            <th>
                                Sender
                            </th>

                            <th>
                                Receiver
                            </th>

                            <th>
                                Location
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Remarks
                            </th>

                            <th>
                                Updated At
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php while ($row = mysqli_fetch_assoc($result)): ?>


                        <?php

                        $statusClass = "";

                        switch ($row['status']) {

                            case "Booked":
                                $statusClass = "booked";
                                break;

                            case "Packed":
                                $statusClass = "packed";
                                break;

                            case "In Transit":
                                $statusClass = "transit";
                                break;

                            case "Out for Delivery":
                                $statusClass = "out";
                                break;

                            case "Delivered":
                                $statusClass = "delivered";
                                break;

                            default:
                                $statusClass = "booked";
                        }

                        ?>


                        <tr>


                            <!-- ID -->

                            <td>

                                <?php
                                echo htmlspecialchars(
                                    $row['tracking_id']
                                );
                                ?>

                            </td>


                            <!-- TRACKING NUMBER -->

                            <td>

                                <span class="tracking-number">

                                    <i class="fa-solid fa-box"></i>

                                    <?php
                                    echo htmlspecialchars(
                                        $row['tracking_number']
                                    );
                                    ?>

                                </span>

                            </td>


                            <!-- SENDER -->

                            <td>

                                <?php
                                echo htmlspecialchars(
                                    $row['sender_name'] ?? 'N/A'
                                );
                                ?>

                            </td>


                            <!-- RECEIVER -->

                            <td>

                                <?php
                                echo htmlspecialchars(
                                    $row['receiver_name']
                                );
                                ?>

                            </td>


                            <!-- LOCATION -->

                            <td>

                                <span class="location">

                                    <i class="fa-solid fa-location-dot"></i>

                                    <?php
                                    echo htmlspecialchars(
                                        $row['location']
                                    );
                                    ?>

                                </span>

                            </td>


                            <!-- STATUS -->

                            <td>

                                <span class="status <?php echo $statusClass; ?>">

                                    <?php
                                    echo htmlspecialchars(
                                        $row['status']
                                    );
                                    ?>

                                </span>

                            </td>


                            <!-- REMARKS -->

                            <td class="remarks">

                                <?php

                                if (!empty($row['remarks'])) {

                                    echo htmlspecialchars(
                                        $row['remarks']
                                    );

                                } else {

                                    echo "—";

                                }

                                ?>

                            </td>


                            <!-- DATE -->

                            <td class="date">

                                <?php

                                echo date(
                                    "d M Y, h:i A",
                                    strtotime($row['updated_at'])
                                );

                                ?>

                            </td>


                        </tr>


                    <?php endwhile; ?>

                    </tbody>

                </table>


            <?php else: ?>


                <div class="empty">

                    <i class="fa-solid fa-clock-rotate-left"></i>

                    <h3>
                        No Tracking History Found
                    </h3>

                    <p>
                        Tracking updates will appear here once a parcel is updated.
                    </p>

                </div>


            <?php endif; ?>

        </div>

    </div>


</div>


</body>

</html>