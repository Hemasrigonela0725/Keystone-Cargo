<?php

include("../includes/db.php");
include("../includes/session.php");

/* =========================================================
   DELETE CUSTOMER
========================================================= */

if (isset($_POST['delete_customer'])) {

    $customer_id = intval($_POST['customer_id']);

    /* Check whether customer has parcels */
    $check = $conn->prepare(
        "SELECT COUNT(*) AS total FROM parcel WHERE customer_id = ?"
    );

    $check->bind_param("i", $customer_id);
    $check->execute();

    $result = $check->get_result();
    $data = $result->fetch_assoc();

    if ($data['total'] > 0) {

        $delete_error =
            "This customer cannot be deleted because parcels are linked to this customer.";

    } else {

        $delete = $conn->prepare(
            "DELETE FROM customer WHERE customer_id = ?"
        );

        $delete->bind_param("i", $customer_id);

        if ($delete->execute()) {
            $delete_success = "Customer deleted successfully.";
        } else {
            $delete_error = "Unable to delete customer.";
        }

        $delete->close();
    }

    $check->close();
}


/* =========================================================
   SEARCH
========================================================= */

$search = "";

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}


/* =========================================================
   GET CUSTOMERS
========================================================= */

if ($search !== "") {

    $stmt = $conn->prepare("
        SELECT
            customer_id,
            full_name,
            phone,
            email,
            address,
            created_at
        FROM customer
        WHERE
            full_name LIKE ?
            OR phone LIKE ?
            OR email LIKE ?
        ORDER BY customer_id DESC
    ");

    $search_value = "%" . $search . "%";

    $stmt->bind_param(
        "sss",
        $search_value,
        $search_value,
        $search_value
    );

} else {

    $stmt = $conn->prepare("
        SELECT
            customer_id,
            full_name,
            phone,
            email,
            address,
            created_at
        FROM customer
        ORDER BY customer_id DESC
    ");
}

$stmt->execute();

$customers = $stmt->get_result();


/* =========================================================
   CUSTOMER STATISTICS
========================================================= */

$total_customers = 0;

$count_query = $conn->query(
    "SELECT COUNT(*) AS total FROM customer"
);

if ($count_query) {
    $count_data = $count_query->fetch_assoc();
    $total_customers = $count_data['total'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Customers | Keystone Cargo</title>


    <!-- FONT AWESOME -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >


    <!-- GOOGLE FONT -->

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet"
    >


    <style>

        /* =====================================================
           RESET
        ===================================================== */

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        body {

            font-family: 'Poppins', sans-serif;

            background:
                radial-gradient(
                    circle at top left,
                    rgba(18, 104, 232, 0.08),
                    transparent 35%
                ),
                #f5f8ff;

            color: #17345f;

            min-height: 100vh;

        }


        /* =====================================================
           PAGE
        ===================================================== */

        .customer-page {

            width: 94%;

            max-width: 1500px;

            margin: 35px auto 60px;

        }


        /* =====================================================
           PAGE HEADER
        ===================================================== */

        .page-header {

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 20px;

            margin-bottom: 28px;

        }


        .page-title-area h1 {

            font-size: 32px;

            font-weight: 700;

            color: #103b78;

            margin-bottom: 6px;

        }


        .page-title-area p {

            color: #71839d;

            font-size: 14px;

        }


        /* =====================================================
           ADD CUSTOMER BUTTON
        ===================================================== */

        .add-customer-btn {

            display: inline-flex;

            align-items: center;

            gap: 9px;

            padding: 13px 22px;

            background: linear-gradient(
                135deg,
                #1268e8,
                #0755c9
            );

            color: #ffffff;

            text-decoration: none;

            border-radius: 10px;

            font-size: 14px;

            font-weight: 600;

            box-shadow:
                0 8px 20px rgba(18,104,232,0.20);

            transition: 0.25s ease;

        }


        .add-customer-btn:hover {

            transform: translateY(-2px);

            box-shadow:
                0 12px 25px rgba(18,104,232,0.28);

        }


        /* =====================================================
           STAT CARD
        ===================================================== */

        .stats-grid {

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 20px;

            margin-bottom: 25px;

        }


        .stat-card {

            background: #ffffff;

            border: 1px solid #e1eaf7;

            border-radius: 16px;

            padding: 22px;

            display: flex;

            align-items: center;

            gap: 16px;

            box-shadow:
                0 8px 25px rgba(30,70,120,0.06);

        }


        .stat-icon {

            width: 52px;

            height: 52px;

            border-radius: 13px;

            display: flex;

            align-items: center;

            justify-content: center;

            background: #eaf2ff;

            color: #1268e8;

            font-size: 21px;

        }


        .stat-info span {

            display: block;

            color: #8293aa;

            font-size: 12px;

            font-weight: 500;

            margin-bottom: 3px;

        }


        .stat-info strong {

            display: block;

            font-size: 24px;

            color: #123d78;

        }


        /* =====================================================
           MAIN CARD
        ===================================================== */

        .customers-card {

            background: #ffffff;

            border: 1px solid #e1eaf7;

            border-radius: 18px;

            box-shadow:
                0 10px 35px rgba(30,70,120,0.07);

            overflow: hidden;

        }


        /* =====================================================
           CARD HEADER
        ===================================================== */

        .customers-card-header {

            padding: 22px 25px;

            display: flex;

            justify-content: space-between;

            align-items: center;

            gap: 20px;

            border-bottom: 1px solid #e9eef6;

        }


        .customers-card-header h2 {

            font-size: 19px;

            color: #123d78;

            font-weight: 600;

        }


        /* =====================================================
           SEARCH
        ===================================================== */

        .search-box {

            position: relative;

            width: 320px;

        }


        .search-box i {

            position: absolute;

            left: 15px;

            top: 50%;

            transform: translateY(-50%);

            color: #8295ae;

        }


        .search-box input {

            width: 100%;

            height: 43px;

            border: 1px solid #dce6f3;

            border-radius: 9px;

            padding: 0 15px 0 43px;

            outline: none;

            font-family: inherit;

            font-size: 13px;

            color: #17345f;

            background: #f9fbff;

            transition: 0.2s ease;

        }


        .search-box input:focus {

            border-color: #1268e8;

            background: #ffffff;

            box-shadow:
                0 0 0 3px rgba(18,104,232,0.08);

        }


        /* =====================================================
           ALERT
        ===================================================== */

        .alert {

            margin: 20px 25px 0;

            padding: 13px 16px;

            border-radius: 9px;

            font-size: 13px;

            display: flex;

            align-items: center;

            gap: 10px;

        }


        .alert-success {

            background: #ecfdf3;

            color: #16794a;

            border: 1px solid #c9f0dc;

        }


        .alert-error {

            background: #fff1f1;

            color: #bd3030;

            border: 1px solid #ffd4d4;

        }


        /* =====================================================
           TABLE
        ===================================================== */

        .table-wrapper {

            width: 100%;

            overflow-x: auto;

        }


        table {

            width: 100%;

            border-collapse: collapse;

            min-width: 950px;

        }


        thead {

            background: #f7faff;

        }


        th {

            padding: 16px 18px;

            text-align: left;

            color: #6f819a;

            font-size: 11px;

            font-weight: 600;

            text-transform: uppercase;

            letter-spacing: 0.5px;

            border-bottom: 1px solid #e6edf7;

        }


        td {

            padding: 18px;

            border-bottom: 1px solid #edf1f7;

            font-size: 13px;

            color: #536983;

            vertical-align: middle;

        }


        tbody tr {

            transition: 0.2s ease;

        }


        tbody tr:hover {

            background: #f8fbff;

        }


        tbody tr:last-child td {

            border-bottom: none;

        }


        /* =====================================================
           CUSTOMER NAME
        ===================================================== */

        .customer-name {

            display: flex;

            align-items: center;

            gap: 12px;

            color: #173f78;

            font-weight: 600;

        }


        .customer-avatar {

            width: 40px;

            height: 40px;

            border-radius: 50%;

            background:
                linear-gradient(
                    135deg,
                    #1268e8,
                    #4d8ff0
                );

            color: #ffffff;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 14px;

            font-weight: 600;

        }


        /* =====================================================
           PHONE
        ===================================================== */

        .phone {

            display: flex;

            align-items: center;

            gap: 8px;

            color: #526b88;

        }


        .phone i {

            color: #1268e8;

            font-size: 12px;

        }


        /* =====================================================
           EMAIL
        ===================================================== */

        .email {

            color: #1268e8;

            font-size: 13px;

        }


        /* =====================================================
           ADDRESS
        ===================================================== */

        .address {

            max-width: 240px;

            line-height: 1.6;

        }


        /* =====================================================
           DATE
        ===================================================== */

        .date {

            white-space: nowrap;

            color: #657994;

        }


        /* =====================================================
           ACTIONS
        ===================================================== */

        .actions {

            display: flex;

            align-items: center;

            gap: 8px;

        }


        .action-btn {

            width: 36px;

            height: 36px;

            border-radius: 8px;

            display: flex;

            align-items: center;

            justify-content: center;

            text-decoration: none;

            border: none;

            cursor: pointer;

            transition: 0.2s ease;

        }


        .edit-btn {

            background: #eaf3ff;

            color: #1268e8;

        }


        .edit-btn:hover {

            background: #1268e8;

            color: #ffffff;

        }


        .delete-btn {

            background: #fff0f0;

            color: #dc3d3d;

        }


        .delete-btn:hover {

            background: #dc3d3d;

            color: #ffffff;

        }


        /* =====================================================
           EMPTY STATE
        ===================================================== */

        .empty-state {

            text-align: center;

            padding: 70px 20px;

        }


        .empty-icon {

            width: 70px;

            height: 70px;

            margin: 0 auto 18px;

            border-radius: 50%;

            display: flex;

            align-items: center;

            justify-content: center;

            background: #edf4ff;

            color: #1268e8;

            font-size: 27px;

        }


        .empty-state h3 {

            color: #173f78;

            font-size: 18px;

            margin-bottom: 7px;

        }


        .empty-state p {

            color: #8797ac;

            font-size: 13px;

        }


        /* =====================================================
           FOOTER INFO
        ===================================================== */

        .table-footer {

            padding: 18px 25px;

            border-top: 1px solid #edf1f7;

            color: #8797ac;

            font-size: 12px;

        }


        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 900px) {

            .customer-page {

                width: 92%;

            }


            .page-header {

                flex-direction: column;

                align-items: flex-start;

            }


            .stats-grid {

                grid-template-columns: 1fr;

            }


            .customers-card-header {

                flex-direction: column;

                align-items: stretch;

            }


            .search-box {

                width: 100%;

            }

        }


        @media (max-width: 600px) {

            .page-title-area h1 {

                font-size: 25px;

            }


            .add-customer-btn {

                width: 100%;

                justify-content: center;

            }

        }

    </style>

</head>


<body>


<div class="customer-page">


    <!-- =====================================================
         PAGE HEADER
    ====================================================== -->

    <div class="page-header">

        <div class="page-title-area">

            <h1>
                Customer Management
            </h1>

            <p>
                Manage and monitor all registered Keystone Cargo customers.
            </p>

        </div>


        <a
            href="add_customer.php"
            class="add-customer-btn"
        >

            <i class="fa-solid fa-user-plus"></i>

            Add Customer

        </a>

    </div>



    <!-- =====================================================
         STATISTICS
    ====================================================== -->

    <div class="stats-grid">


        <div class="stat-card">

            <div class="stat-icon">

                <i class="fa-solid fa-users"></i>

            </div>

            <div class="stat-info">

                <span>Total Customers</span>

                <strong>
                    <?php echo $total_customers; ?>
                </strong>

            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">

                <i class="fa-solid fa-user-check"></i>

            </div>

            <div class="stat-info">

                <span>Registered Customers</span>

                <strong>
                    <?php echo $total_customers; ?>
                </strong>

            </div>

        </div>


        <div class="stat-card">

            <div class="stat-icon">

                <i class="fa-solid fa-address-book"></i>

            </div>

            <div class="stat-info">

                <span>Customer Directory</span>

                <strong>
                    Active
                </strong>

            </div>

        </div>


    </div>



    <!-- =====================================================
         CUSTOMER CARD
    ====================================================== -->

    <div class="customers-card">


        <div class="customers-card-header">

            <h2>
                <i
                    class="fa-solid fa-users"
                    style="color:#1268e8;margin-right:8px;"
                ></i>

                Customer Directory

            </h2>


            <form
                method="GET"
                class="search-box"
            >

                <i class="fa-solid fa-magnifying-glass"></i>

                <input
                    type="text"
                    name="search"
                    placeholder="Search customer..."
                    value="<?php echo htmlspecialchars($search); ?>"
                >

            </form>

        </div>



        <!-- =================================================
             ALERTS
        ================================================== -->

        <?php if (isset($delete_success)): ?>

            <div class="alert alert-success">

                <i class="fa-solid fa-circle-check"></i>

                <?php echo htmlspecialchars($delete_success); ?>

            </div>

        <?php endif; ?>


        <?php if (isset($delete_error)): ?>

            <div class="alert alert-error">

                <i class="fa-solid fa-circle-exclamation"></i>

                <?php echo htmlspecialchars($delete_error); ?>

            </div>

        <?php endif; ?>



        <!-- =================================================
             CUSTOMER TABLE
        ================================================== -->

        <?php if ($customers->num_rows > 0): ?>


            <div class="table-wrapper">

                <table>

                    <thead>

                        <tr>

                            <th>
                                Customer
                            </th>

                            <th>
                                Phone
                            </th>

                            <th>
                                Email
                            </th>

                            <th>
                                Address
                            </th>

                            <th>
                                Registered
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                    <?php while ($customer = $customers->fetch_assoc()): ?>


                        <?php

                        $name = $customer['full_name'];

                        $initial = strtoupper(
                            substr(trim($name), 0, 1)
                        );

                        ?>


                        <tr>


                            <!-- CUSTOMER -->

                            <td>

                                <div class="customer-name">

                                    <div class="customer-avatar">

                                        <?php
                                        echo htmlspecialchars($initial);
                                        ?>

                                    </div>


                                    <div>

                                        <?php
                                        echo htmlspecialchars($name);
                                        ?>

                                    </div>

                                </div>

                            </td>



                            <!-- PHONE -->

                            <td>

                                <div class="phone">

                                    <i class="fa-solid fa-phone"></i>

                                    <?php
                                    echo htmlspecialchars(
                                        $customer['phone']
                                    );
                                    ?>

                                </div>

                            </td>



                            <!-- EMAIL -->

                            <td>

                                <span class="email">

                                    <?php
                                    echo htmlspecialchars(
                                        $customer['email']
                                    );
                                    ?>

                                </span>

                            </td>



                            <!-- ADDRESS -->

                            <td>

                                <div class="address">

                                    <?php
                                    echo htmlspecialchars(
                                        $customer['address']
                                    );
                                    ?>

                                </div>

                            </td>



                            <!-- DATE -->

                            <td>

                                <div class="date">

                                    <?php

                                    echo date(
                                        "d M Y",
                                        strtotime(
                                            $customer['created_at']
                                        )
                                    );

                                    ?>

                                </div>

                            </td>



                            <!-- ACTIONS -->

                            <td>

                                <div class="actions">


                                    <!-- EDIT -->

                                    <a
                                        href="edit_customer.php?id=<?php echo $customer['customer_id']; ?>"
                                        class="action-btn edit-btn"
                                        title="Edit Customer"
                                    >

                                        <i class="fa-solid fa-pen"></i>

                                    </a>



                                    <!-- DELETE -->

                                    <form
                                        method="POST"
                                        onsubmit="return confirm(
                                            'Are you sure you want to delete this customer?'
                                        );"
                                    >

                                        <input
                                            type="hidden"
                                            name="customer_id"
                                            value="<?php echo $customer['customer_id']; ?>"
                                        >

                                        <button
                                            type="submit"
                                            name="delete_customer"
                                            class="action-btn delete-btn"
                                            title="Delete Customer"
                                        >

                                            <i class="fa-solid fa-trash"></i>

                                        </button>

                                    </form>


                                </div>

                            </td>


                        </tr>


                    <?php endwhile; ?>


                    </tbody>

                </table>

            </div>


            <div class="table-footer">

                Showing
                <strong>
                    <?php echo $customers->num_rows; ?>
                </strong>
                customer(s)

            </div>


        <?php else: ?>


            <!-- EMPTY -->

            <div class="empty-state">

                <div class="empty-icon">

                    <i class="fa-solid fa-user-group"></i>

                </div>


                <h3>
                    No Customers Found
                </h3>


                <p>

                    <?php if ($search !== ""): ?>

                        No customers match your search.

                    <?php else: ?>

                        No customers have been registered yet.

                    <?php endif; ?>

                </p>

            </div>


        <?php endif; ?>


    </div>


</div>



<script>

    /* =====================================================
       AUTO HIDE ALERTS
    ===================================================== */

    setTimeout(function () {

        const alerts =
            document.querySelectorAll('.alert');

        alerts.forEach(function (alert) {

            alert.style.transition =
                'opacity 0.5s ease';

            alert.style.opacity = '0';

            setTimeout(function () {

                alert.remove();

            }, 500);

        });

    }, 4000);

</script>


</body>

</html>