<?php
session_start();

include("../includes/db.php");

/* Check admin login */
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}


/* =========================
   FETCH PARCELS
========================= */

$sql = "SELECT
            p.parcel_id,
            p.tracking_number,
            p.receiver_name,
            p.receiver_phone,
            p.receiver_address,
            p.parcel_type,
            p.weight,
            p.booking_date,
            p.status,
            p.sender_address,
            p.estimated_delivery,
            c.full_name AS sender_name
        FROM parcel p
        LEFT JOIN customer c
            ON p.customer_id = c.customer_id
        ORDER BY p.parcel_id DESC";

$result = mysqli_query($conn, $sql);

if (!$result) {
    die("Unable to fetch parcels: " . mysqli_error($conn));
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Parcels | Keystone Cargo</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial,sans-serif;
}

body{
    background:#f4f7fc;
    color:#102a56;
}


/* ================= NAVBAR ================= */

.navbar{
    min-height:80px;
    background:linear-gradient(90deg,#0d3b82,#1269ed);
    display:flex;
    align-items:center;
    padding:0 5%;
    color:white;
}

.logo{
    display:flex;
    align-items:center;
    gap:12px;
}

.logo i{
    font-size:30px;
    color:#ffc107;
}

.logo h2{
    font-size:25px;
}

.nav-right{
    margin-left:auto;
    display:flex;
    align-items:center;
    gap:25px;
}

.nav-right a{
    color:white;
    text-decoration:none;
    font-size:16px;
}

.nav-right a:hover{
    color:#ffc107;
}

.logout{
    background:#dc3545;
    padding:10px 18px;
    border-radius:8px;
}


/* ================= CONTAINER ================= */

.container{
    width:94%;
    max-width:1400px;
    margin:45px auto;
}


/* ================= HEADER ================= */

.page-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

.page-header h1{
    font-size:36px;
    color:#102a56;
}

.page-header p{
    margin-top:7px;
    color:#777;
}

.book-btn{
    background:#1269ed;
    color:white;
    text-decoration:none;
    padding:14px 22px;
    border-radius:10px;
    font-weight:bold;
}

.book-btn:hover{
    background:#0d56c7;
}


/* ================= MESSAGE ================= */

.message{
    padding:16px 20px;
    border-radius:10px;
    margin-bottom:25px;
    font-size:16px;
}

.success{
    background:#dff5e5;
    color:#176b35;
    border:1px solid #a9dfb8;
}


/* ================= TABLE CARD ================= */

.table-card{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 12px 35px rgba(0,0,0,0.08);
    overflow-x:auto;
}

.parcel-table{
    width:100%;
    border-collapse:collapse;
    min-width:1200px;
}


/* ================= TABLE HEADER ================= */

.parcel-table th{
    background:#0d3b82;
    color:white;
    padding:17px 14px;
    text-align:left;
    font-size:15px;
    white-space:nowrap;
}

.parcel-table th:first-child{
    border-radius:8px 0 0 8px;
}

.parcel-table th:last-child{
    border-radius:0 8px 8px 0;
}


/* ================= TABLE BODY ================= */

.parcel-table td{
    padding:16px 14px;
    border-bottom:1px solid #e8edf5;
    color:#444;
    vertical-align:middle;
}

.parcel-table tbody tr{
    transition:0.2s;
}

.parcel-table tbody tr:hover{
    background:#f5f8ff;
}


/* ================= TRACKING NUMBER ================= */

.tracking-number{
    color:#1269ed;
    font-weight:bold;
    font-size:16px;
}


/* ================= SENDER ================= */

.sender-name{
    font-weight:bold;
    color:#102a56;
}


/* ================= STATUS ================= */

.status{
    display:inline-block;
    padding:8px 13px;
    border-radius:20px;
    font-size:13px;
    font-weight:bold;
    white-space:nowrap;
}

.booked{
    background:#e8f1ff;
    color:#1269ed;
}

.packed{
    background:#fff3cd;
    color:#856404;
}

.transit{
    background:#e4eaff;
    color:#4c42b8;
}

.out{
    background:#ffe7cc;
    color:#b65b00;
}

.delivered{
    background:#dff5e5;
    color:#176b35;
}


/* ================= ACTIONS ================= */

.actions{
    display:flex;
    gap:8px;
    white-space:nowrap;
}

.action-btn{
    text-decoration:none;
    padding:9px 12px;
    border-radius:7px;
    font-size:13px;
    font-weight:bold;
}

.update-btn{
    background:#e3efff;
    color:#1269ed;
}

.update-btn:hover{
    background:#1269ed;
    color:white;
}

.track-btn{
    background:#e6f7ed;
    color:#198754;
}

.track-btn:hover{
    background:#198754;
    color:white;
}


/* ================= EMPTY ================= */

.empty{
    text-align:center;
    padding:70px 20px;
    color:#777;
}

.empty i{
    font-size:55px;
    color:#b8c4d6;
    margin-bottom:15px;
}

.empty h3{
    font-size:24px;
    color:#555;
    margin-bottom:8px;
}


/* ================= FOOTER ================= */

.footer{
    text-align:center;
    padding:25px;
    margin-top:60px;
    background:#0d3b82;
    color:white;
}


/* ================= RESPONSIVE ================= */

@media(max-width:700px){

    .navbar{
        padding:18px 20px;
        flex-direction:column;
        gap:15px;
    }

    .nav-right{
        margin-left:0;
        flex-wrap:wrap;
        justify-content:center;
    }

    .page-header{
        flex-direction:column;
        align-items:flex-start;
        gap:20px;
    }

    .book-btn{
        width:100%;
        text-align:center;
    }

}

</style>

</head>


<body>


<!-- ================= NAVBAR ================= -->

<nav class="navbar">

    <div class="logo">

        <i class="fa-solid fa-truck-fast"></i>

        <h2>
            Keystone Cargo
        </h2>

    </div>


    <div class="nav-right">

        <a href="dashboard.php">

            <i class="fa-solid fa-gauge"></i>

            Dashboard

        </a>


        <a href="view_customer.php">

            <i class="fa-solid fa-users"></i>

            Customers

        </a>


        <a href="logout.php"
           class="logout">

            <i class="fa-solid fa-right-from-bracket"></i>

            Logout

        </a>

    </div>

</nav>


<!-- ================= MAIN ================= -->

<div class="container">


    <div class="page-header">

        <div>

            <h1>

                <i class="fa-solid fa-boxes-stacked"></i>

                Parcels

            </h1>

            <p>
                Manage and monitor all Keystone Cargo parcels.
            </p>

        </div>


        <a href="add_parcel.php"
           class="book-btn">

            <i class="fa-solid fa-box-open"></i>

            Book New Parcel

        </a>

    </div>


    <!-- ================= SUCCESS MESSAGE ================= -->

    <?php if (isset($_GET['added'])): ?>

        <div class="message success">

            <i class="fa-solid fa-circle-check"></i>

            Parcel booked successfully.

            <?php if (isset($_GET['tracking'])): ?>

                Tracking Number:

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $_GET['tracking']
                    );
                    ?>
                </strong>

            <?php endif; ?>

        </div>

    <?php endif; ?>


    <!-- ================= TABLE ================= -->

    <div class="table-card">


        <?php if (mysqli_num_rows($result) > 0): ?>


            <table class="parcel-table">

                <thead>

                    <tr>

                        <th>
                            ID
                        </th>

                        <th>
                            Tracking Number
                        </th>

                        <th>
                            Sender
                        </th>

                        <th>
                            Receiver
                        </th>

                        <th>
                            Parcel Type
                        </th>

                        <th>
                            Weight
                        </th>

                        <th>
                            Booking Date
                        </th>

                        <th>
                            Estimated Delivery
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Actions
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php while (
                    $parcel =
                    mysqli_fetch_assoc($result)
                ): ?>


                    <tr>


                        <!-- ID -->

                        <td>

                            <strong>
                                #<?php
                                echo htmlspecialchars(
                                    $parcel['parcel_id']
                                );
                                ?>
                            </strong>

                        </td>


                        <!-- TRACKING -->

                        <td class="tracking-number">

                            <?php
                            echo htmlspecialchars(
                                $parcel['tracking_number']
                            );
                            ?>

                        </td>


                        <!-- SENDER -->

                        <td class="sender-name">

                            <?php

                            if (
                                !empty(
                                    $parcel['sender_name']
                                )
                            ) {

                                echo htmlspecialchars(
                                    $parcel['sender_name']
                                );

                            } else {

                                echo "N/A";

                            }

                            ?>

                        </td>


                        <!-- RECEIVER -->

                        <td>

                            <?php
                            echo htmlspecialchars(
                                $parcel['receiver_name']
                            );
                            ?>

                        </td>


                        <!-- TYPE -->

                        <td>

                            <?php
                            echo htmlspecialchars(
                                $parcel['parcel_type']
                            );
                            ?>

                        </td>


                        <!-- WEIGHT -->

                        <td>

                            <?php
                            echo htmlspecialchars(
                                $parcel['weight']
                            );
                            ?>
                            kg

                        </td>


                        <!-- BOOKING DATE -->

                        <td>

                            <?php
                            echo htmlspecialchars(
                                $parcel['booking_date']
                            );
                            ?>

                        </td>


                        <!-- DELIVERY -->

                        <td>

                            <?php
                            echo htmlspecialchars(
                                $parcel['estimated_delivery']
                            );
                            ?>

                        </td>


                        <!-- STATUS -->

                        <td>

                            <?php

                            $status =
                                $parcel['status'];

                            $status_class = "";

                            switch (
                                strtolower($status)
                            ) {

                                case "booked":
                                    $status_class = "booked";
                                    break;

                                case "packed":
                                    $status_class = "packed";
                                    break;

                                case "in transit":
                                    $status_class = "transit";
                                    break;

                                case "out for delivery":
                                    $status_class = "out";
                                    break;

                                case "delivered":
                                    $status_class = "delivered";
                                    break;

                                default:
                                    $status_class = "booked";
                            }

                            ?>

                            <span
                                class="status <?php echo $status_class; ?>">

                                <?php
                                echo htmlspecialchars(
                                    $status
                                );
                                ?>

                            </span>

                        </td>


                        <!-- ACTIONS -->

                        <td>

                            <div class="actions">


                         <a href="update_tracking.php?id=<?php echo $parcel['parcel_id']; ?>"
   class="action-btn update-btn">
    <i class="fa-solid fa-pen-to-square"></i>
    Update Status
</a>

<a href="view_tracking.php?id=<?php echo $parcel['parcel_id']; ?>"
   class="action-btn track-btn">
    <i class="fa-solid fa-route"></i>
    Track
</a>

<a href="tracking_history.php?id=<?php echo $parcel['parcel_id']; ?>"
   class="action-btn history-btn">
    <i class="fa-solid fa-clock-rotate-left"></i>
    History
</a>       

                            </div>

                        </td>


                    </tr>


                <?php endwhile; ?>


                </tbody>

            </table>


        <?php else: ?>


            <div class="empty">

                <i class="fa-solid fa-box-open"></i>

                <h3>
                    No Parcels Found
                </h3>

                <p>
                    Book your first parcel to see it here.
                </p>

            </div>


        <?php endif; ?>


    </div>

</div>


<!-- ================= FOOTER ================= -->

<footer class="footer">

    © <?php echo date("Y"); ?> Keystone Cargo.
    All Rights Reserved.

</footer>


</body>

</html>