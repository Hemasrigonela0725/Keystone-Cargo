<?php
session_start();

if(!isset($_SESSION['admin']))
{
    header("Location: login.php");
    exit();
}

include("../includes/db.php");

$message = "";

if(isset($_POST['save']))
{
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);

    $sql = "INSERT INTO customer(full_name, phone, email, address)
            VALUES('$full_name','$phone','$email','$address')";

    if(mysqli_query($conn,$sql))
    {
        $message = "<div class='alert alert-success'>
                        Customer Added Successfully.
                    </div>";
    }
    else
    {
        $message = "<div class='alert alert-danger'>
                        Error : ".mysqli_error($conn)."
                    </div>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Add Customer</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#f4f7fc;
}

.container{
    max-width:700px;
    margin-top:50px;
}

.card{
    border:none;
    border-radius:12px;
    box-shadow:0 5px 20px rgba(0,0,0,.1);
}

.card-header{
    background:#0d6efd;
    color:white;
    font-size:22px;
    font-weight:bold;
}

.btn-primary{
    width:100%;
}

</style>

</head>

<body>

<div class="container">

<div class="card">

<div class="card-header">
Add Customer
</div>

<div class="card-body">

<?php echo $message; ?>

<form method="POST">

<div class="mb-3">
<label class="form-label">Full Name</label>
<input
type="text"
name="full_name"
class="form-control"
required>
</div>

<div class="mb-3">
<label class="form-label">Phone Number</label>
<input
type="text"
name="phone"
class="form-control"
required>
</div>

<div class="mb-3">
<label class="form-label">Email Address</label>
<input
type="email"
name="email"
class="form-control"
required>
</div>

<div class="mb-3">
<label class="form-label">Address</label>
<textarea
name="address"
class="form-control"
rows="4"
required></textarea>
</div>

<button
type="submit"
name="save"
class="btn btn-primary">
Save Customer
</button>

<a href="dashboard.php"
class="btn btn-secondary mt-3 w-100">
Back to Dashboard
</a>

</form>

</div>

</div>

</div>

</body>
</html>