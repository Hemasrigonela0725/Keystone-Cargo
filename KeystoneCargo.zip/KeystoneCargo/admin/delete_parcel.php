<?php
include("../includes/session.php");
include("../includes/db.php");

if(isset($_GET['id']))
{
    $id = $_GET['id'];

    mysqli_query($conn,"DELETE FROM parcel WHERE parcel_id='$id'");

    echo "<script>
            alert('Parcel Deleted Successfully');
            window.location='view_parcel.php';
          </script>";
}
else
{
    header("Location:view_parcel.php");
    exit();
}
?>