<?php
session_start();
include("../includes/db.php");

$error = "";

if(isset($_POST['login']))
{
    $username = mysqli_real_escape_string($conn,$_POST['username']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);

    $sql = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn,$sql);

    if(mysqli_num_rows($result) > 0)
    {
        $_SESSION['admin'] = $username;
        header("Location: dashboard.php");
        exit();
    }
    else
    {
        $error = "Invalid Username or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Login | Keystone Cargo</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{

    height:100vh;

    display:flex;

    justify-content:center;

    align-items:center;

    background:linear-gradient(135deg,#071A52,#0B3D91,#145DA0);

    overflow:hidden;

}

/* Animated Background */

body::before{

    content:"";

    position:absolute;

    width:200%;

    height:200%;

    background-image:

    linear-gradient(rgba(255,255,255,.05) 1px,transparent 1px),

    linear-gradient(90deg,rgba(255,255,255,.05) 1px,transparent 1px);

    background-size:60px 60px;

    animation:moveGrid 25s linear infinite;

}

@keyframes moveGrid{

    from{
        transform:translate(0,0);
    }

    to{
        transform:translate(-60px,-60px);
    }

}

.login-box{

    position:relative;

    z-index:10;

    width:430px;

    background:white;

    padding:40px;

    border-radius:20px;

    box-shadow:0 15px 35px rgba(0,0,0,.25);

}

.logo{

    text-align:center;

    margin-bottom:15px;

}

.logo i{

    font-size:60px;

    color:#0B3D91;

}

h2{

    text-align:center;

    color:#0B3D91;

    font-weight:700;

    margin-bottom:5px;

}

.subtitle{

    text-align:center;

    color:#777;

    margin-bottom:30px;

}

.form-control{

    height:48px;

}

.input-group button{

    border-left:0;

}

.btn-login{

    width:100%;

    height:48px;

    background:#0B3D91;

    color:white;

    font-weight:600;

    border:none;

    transition:.3s;

}

.btn-login:hover{

    background:#082d6d;

}

.footer-text{

    text-align:center;

    margin-top:20px;

    color:#777;

    font-size:14px;

}

</style>

</head>

<body>

<div class="login-box">

<div class="logo">

<i class="fa-solid fa-truck-fast"></i>

</div>

<h2>Keystone Cargo</h2>

<p class="subtitle">

Courier Tracking System

</p>

<?php

if($error!="")
{
    echo "<div class='alert alert-danger'>$error</div>";
}

?>

<form method="post" autocomplete="off">

<div class="mb-3">

<label class="form-label">

Username

</label>

<input
type="text"
name="username"
class="form-control"
placeholder="Enter Username"
autocomplete="off"
required>

</div>

<div class="mb-3">

<label class="form-label">

Password

</label>

<div class="input-group">

<input
type="password"
name="password"
id="password"
class="form-control"
placeholder="Enter Password"
autocomplete="new-password"
required>

<button
class="btn btn-outline-secondary"
type="button"
id="togglePassword">

<i class="fa-solid fa-eye"></i>

</button>

</div>

</div>

<div class="d-grid">

<button
type="submit"
name="login"
class="btn btn-login">

<i class="fa-solid fa-right-to-bracket"></i>

 Login

</button>

</div>

</form>

<div class="footer-text">

© <?php echo date("Y"); ?>

Keystone Cargo

</div>

</div>

<script>

const togglePassword=document.getElementById("togglePassword");

const password=document.getElementById("password");

togglePassword.addEventListener("click",function(){

if(password.type==="password")
{
password.type="text";

this.innerHTML='<i class="fa-solid fa-eye-slash"></i>';
}
else
{
password.type="password";

this.innerHTML='<i class="fa-solid fa-eye"></i>';
}

});

</script>

</body>

</html>