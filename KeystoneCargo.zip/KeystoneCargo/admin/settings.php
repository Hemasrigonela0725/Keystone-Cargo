<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Settings | Keystone Cargo</title>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f4f7fc;
            color: #222;
        }

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: linear-gradient(180deg, #164a9c, #0b3475);
            color: white;
            padding: 30px 20px;
        }

        .logo {
            font-size: 28px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 45px;
        }

        .menu a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 15px;
            margin-bottom: 8px;
            border-radius: 8px;
            font-size: 17px;
            transition: 0.3s;
        }

        .menu a:hover,
        .menu a.active {
            background: rgba(255,255,255,0.15);
            transform: translateX(5px);
        }

        .menu i {
            width: 28px;
        }

        .main {
            margin-left: 260px;
            padding: 40px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .header h1 {
            font-size: 34px;
            color: #123b7a;
        }

        .admin-name {
            background: white;
            padding: 12px 20px;
            border-radius: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            color: #123b7a;
            font-weight: bold;
        }

        .settings-container {
            max-width: 900px;
        }

        .card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }

        .card h2 {
            color: #123b7a;
            margin-bottom: 10px;
            font-size: 23px;
        }

        .card p {
            color: #666;
            margin-bottom: 25px;
        }

        .setting-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 18px 0;
            border-bottom: 1px solid #eee;
        }

        .setting-row:last-child {
            border-bottom: none;
        }

        .setting-info h3 {
            font-size: 17px;
            margin-bottom: 5px;
        }

        .setting-info span {
            color: #777;
            font-size: 14px;
        }

        .status {
            background: #e8f7ed;
            color: #16833b;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 14px;
        }

        .btn {
            display: inline-block;
            background: #165fd3;
            color: white;
            text-decoration: none;
            padding: 12px 22px;
            border-radius: 8px;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn:hover {
            background: #0d47a1;
            transform: translateY(-2px);
        }

        .logout {
            margin-top: 25px;
            background: #dc3545 !important;
        }

        .logout:hover {
            background: #b02a37 !important;
        }

        @media (max-width: 800px) {

            .sidebar {
                width: 210px;
            }

            .main {
                margin-left: 210px;
                padding: 25px;
            }

            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }

        @media (max-width: 600px) {

            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .main {
                margin-left: 0;
                padding: 20px;
            }

            .setting-row {
                flex-direction: column;
                align-items: flex-start;
                gap: 12px;
            }
        }
    </style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">

    <div class="logo">
        Keystone Cargo
    </div>

    <div class="menu">

        <a href="dashboard.php">
            <i class="fa-solid fa-house"></i>
            Dashboard
        </a>

        <a href="view_customer.php">
            <i class="fa-solid fa-users"></i>
            Customers
        </a>

        <a href="view_parcel.php">
            <i class="fa-solid fa-box"></i>
            Parcels
        </a>

        <a href="tracking_history.php">
            <i class="fa-solid fa-location-dot"></i>
            Tracking
        </a>

        <a href="reports.php">
            <i class="fa-solid fa-chart-column"></i>
            Reports
        </a>

        <a href="settings.php" class="active">
            <i class="fa-solid fa-gear"></i>
            Settings
        </a>

        <a href="logout.php" class="logout">
            <i class="fa-solid fa-right-from-bracket"></i>
            Logout
        </a>

    </div>

</div>


<!-- MAIN CONTENT -->
<div class="main">

    <div class="header">

        <h1>
            <i class="fa-solid fa-gear"></i>
            Settings
        </h1>

        <div class="admin-name">
            <i class="fa-solid fa-user"></i>
            <?php echo htmlspecialchars($_SESSION['admin']); ?>
        </div>

    </div>


    <div class="settings-container">

        <!-- SYSTEM INFORMATION -->
        <div class="card">

            <h2>
                <i class="fa-solid fa-circle-info"></i>
                System Information
            </h2>

            <p>
                Information about your Keystone Cargo tracking system.
            </p>

            <div class="setting-row">

                <div class="setting-info">
                    <h3>System Name</h3>
                    <span>Application name</span>
                </div>

                <strong>Keystone Cargo</strong>

            </div>


            <div class="setting-row">

                <div class="setting-info">
                    <h3>Database</h3>
                    <span>Connected database</span>
                </div>

                <strong>keystonecargo</strong>

            </div>


            <div class="setting-row">

                <div class="setting-info">
                    <h3>System Status</h3>
                    <span>Current application status</span>
                </div>

                <span class="status">
                    <i class="fa-solid fa-circle-check"></i>
                    Active
                </span>

            </div>

        </div>


        <!-- ADMIN INFORMATION -->
        <div class="card">

            <h2>
                <i class="fa-solid fa-user-shield"></i>
                Administrator
            </h2>

            <p>
                Current administrator account information.
            </p>

            <div class="setting-row">

                <div class="setting-info">
                    <h3>Username</h3>
                    <span>Currently logged-in administrator</span>
                </div>

                <strong>
                    <?php echo htmlspecialchars($_SESSION['admin']); ?>
                </strong>

            </div>


            <div class="setting-row">

                <div class="setting-info">
                    <h3>Access Level</h3>
                    <span>Administrator permissions</span>
                </div>

                <span class="status">
                    Administrator
                </span>

            </div>

        </div>


        <!-- ACCOUNT -->
        <div class="card">

            <h2>
                <i class="fa-solid fa-lock"></i>
                Account
            </h2>

            <p>
                Manage your current administrator session.
            </p>

            <a href="logout.php" class="btn">
                <i class="fa-solid fa-right-from-bracket"></i>
                Logout
            </a>

        </div>

    </div>

</div>

</body>
</html>