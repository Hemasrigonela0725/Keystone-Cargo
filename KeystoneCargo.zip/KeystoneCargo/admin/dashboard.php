<?php
include("../includes/session.php");
include("../includes/db.php");

/* Dashboard Counts */

$customers = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM customer")
)['total'];

$parcels = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM parcel")
)['total'];

$booked = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM parcel WHERE status='Booked'")
)['total'];

$transit = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM parcel WHERE status='In Transit'")
)['total'];

$out_delivery = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM parcel WHERE status='Out for Delivery'")
)['total'];

$delivered = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM parcel WHERE status='Delivered'")
)['total'];
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Admin Dashboard | Keystone Cargo</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
rel="stylesheet">

<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    font-family:Arial,sans-serif;
    background:#f4f7fc;
}

/* Sidebar */

.sidebar{

    position:fixed;

    left:0;
    top:0;

    width:250px;
    height:100vh;

    background:linear-gradient(
        180deg,
        #071d49,
        #0d6efd
    );

    color:white;

    padding:25px 15px;

}

.logo{

    text-align:center;

    margin-bottom:35px;

}

.logo h2{

    font-weight:bold;
    margin:0;

}

.logo p{

    margin:5px 0 0;

    font-size:13px;

    opacity:.8;

}

.menu a{

    display:block;

    color:white;

    text-decoration:none;

    padding:13px 15px;

    margin-bottom:7px;

    border-radius:8px;

    transition:.3s;

}

.menu a:hover{

    background:rgba(255,255,255,.15);

    transform:translateX(4px);

}

.menu i{

    width:25px;

}

.logout{

    position:absolute;

    bottom:25px;

    left:15px;

    right:15px;

}

.logout a{

    background:#dc3545;

}

/* Main */

.main{

    margin-left:250px;

    padding:30px;

}

/* Top */

.topbar{

    background:white;

    padding:20px 25px;

    border-radius:15px;

    box-shadow:
    0 5px 20px rgba(0,0,0,.06);

    margin-bottom:30px;

}

.topbar h1{

    margin:0;

    color:#0b3d91;

    font-size:28px;

}

.topbar p{

    margin:5px 0 0;

    color:#777;

}

/* Statistics */

.stats{

    display:grid;

    grid-template-columns:
    repeat(3,1fr);

    gap:20px;

}

.stat{

    background:white;

    padding:25px;

    border-radius:15px;

    box-shadow:
    0 5px 20px rgba(0,0,0,.06);

    display:flex;

    align-items:center;

    gap:18px;

}

.icon{

    width:55px;

    height:55px;

    border-radius:12px;

    display:flex;

    align-items:center;

    justify-content:center;

    background:#e8f1ff;

    color:#0d6efd;

    font-size:23px;

}

.stat h3{

    margin:0;

    color:#0b3d91;

}

.stat p{

    margin:4px 0 0;

    color:#777;

}

/* Quick Actions */

.actions{

    margin-top:30px;

    background:white;

    padding:25px;

    border-radius:15px;

    box-shadow:
    0 5px 20px rgba(0,0,0,.06);

}

.actions h3{

    color:#0b3d91;

    margin-bottom:20px;

}

.action-grid{

    display:grid;

    grid-template-columns:
    repeat(3,1fr);

    gap:15px;

}

.action{

    text-decoration:none;

    color:#222;

    border:1px solid #e1e6ee;

    padding:20px;

    border-radius:10px;

    transition:.3s;

}

.action:hover{

    border-color:#0d6efd;

    transform:translateY(-3px);

    box-shadow:
    0 5px 15px rgba(13,110,253,.12);

}

.action i{

    color:#0d6efd;

    font-size:22px;

    margin-bottom:10px;

}

.action strong{

    display:block;

}

.action span{

    color:#777;

    font-size:13px;

}

/* Mobile */

@media(max-width:900px){

    .sidebar{

        width:210px;

    }

    .main{

        margin-left:210px;

    }

    .stats{

        grid-template-columns:
        repeat(2,1fr);

    }

    .action-grid{

        grid-template-columns:
        repeat(2,1fr);

    }

}

@media(max-width:650px){

    .sidebar{

        position:relative;

        width:100%;

        height:auto;

    }

    .logout{

        position:static;

        margin-top:15px;

    }

    .main{

        margin-left:0;

        padding:20px;

    }

    .stats{

        grid-template-columns:1fr;

    }

    .action-grid{

        grid-template-columns:1fr;

    }

}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

<div class="logo">

<h2>Keystone Cargo</h2>

<p>Admin Panel</p>

</div>

<div class="menu">

<a href="dashboard.php">

<i class="fa-solid fa-chart-line"></i>

Dashboard

</a>

<a href="add_customer.php">

<i class="fa-solid fa-user-plus"></i>

Add Customer

</a>

<a href="view_customer.php">

<i class="fa-solid fa-users"></i>

View Customers

</a>

<a href="add_parcel.php">

<i class="fa-solid fa-box"></i>

Add Parcel

</a>

<a href="view_parcel.php">

<i class="fa-solid fa-boxes-stacked"></i>

View Parcels

</a>

<a href="update_tracking.php">

<i class="fa-solid fa-location-dot"></i>

Update Tracking

</a>

<a href="tracking_history.php">

<i class="fa-solid fa-clock-rotate-left"></i>

Tracking History

</a>

<a href="reports.php">

<i class="fa-solid fa-file-lines"></i>

Reports

</a>

</div>

<div class="logout">

<a href="logout.php">

<i class="fa-solid fa-right-from-bracket"></i>

Logout

</a>

</div>

</div>


<!-- MAIN -->

<div class="main">

<div class="topbar">

<h1>

Admin Dashboard

</h1>

<p>

Welcome to Keystone Cargo Management System

</p>

</div>


<!-- STATISTICS -->

<div class="stats">

<div class="stat">

<div class="icon">

<i class="fa-solid fa-users"></i>

</div>

<div>

<h3>
<?php echo $customers; ?>
</h3>

<p>Customers</p>

</div>

</div>


<div class="stat">

<div class="icon">

<i class="fa-solid fa-box"></i>

</div>

<div>

<h3>
<?php echo $parcels; ?>
</h3>

<p>Total Parcels</p>

</div>

</div>


<div class="stat">

<div class="icon">

<i class="fa-solid fa-clipboard-list"></i>

</div>

<div>

<h3>
<?php echo $booked; ?>
</h3>

<p>Booked</p>

</div>

</div>


<div class="stat">

<div class="icon">

<i class="fa-solid fa-truck-fast"></i>

</div>

<div>

<h3>
<?php echo $transit; ?>
</h3>

<p>In Transit</p>

</div>

</div>


<div class="stat">

<div class="icon">

<i class="fa-solid fa-truck"></i>

</div>

<div>

<h3>
<?php echo $out_delivery; ?>
</h3>

<p>Out for Delivery</p>

</div>

</div>


<div class="stat">

<div class="icon">

<i class="fa-solid fa-circle-check"></i>

</div>

<div>

<h3>
<?php echo $delivered; ?>
</h3>

<p>Delivered</p>

</div>

</div>

</div>


<!-- QUICK ACTIONS -->

<div class="actions">

<h3>Quick Actions</h3>

<div class="action-grid">

<a
href="add_customer.php"
class="action">

<i class="fa-solid fa-user-plus"></i>

<strong>Add Customer</strong>

<span>Create a new customer</span>

</a>


<a
href="add_parcel.php"
class="action">

<i class="fa-solid fa-box-open"></i>

<strong>Book Parcel</strong>

<span>Create a new parcel booking</span>

</a>


<a
href="update_tracking.php"
class="action">

<i class="fa-solid fa-location-dot"></i>

<strong>Update Tracking</strong>

<span>Update parcel status</span>

</a>


<a
href="view_parcel.php"
class="action">

<i class="fa-solid fa-boxes-stacked"></i>

<strong>View Parcels</strong>

<span>Manage all parcels</span>

</a>


<a
href="tracking_history.php"
class="action">

<i class="fa-solid fa-clock-rotate-left"></i>

<strong>Tracking History</strong>

<span>View parcel movement</span>

</a>


<a
href="reports.php"
class="action">

<i class="fa-solid fa-file-lines"></i>

<strong>Reports</strong>

<span>View system reports</span>

</a>

</div>

</div>

</div>

</body>

</html>