<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include("../includes/db.php");

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: tracking_history.php");
    exit();
}

$parcel_id = intval($_GET['id']);

/* Get parcel information */
$sql = "
    SELECT 
        p.parcel_id,
        p.tracking_number,
        p.receiver_name,
        p.receiver_phone,
        p.receiver_address,
        p.parcel_type,
        p.weight,
        p.booking_date,
        p.status,
        p.sender_address,
        p.estimated_delivery,
        c.full_name AS sender_name
    FROM parcel p
    LEFT JOIN customer c 
        ON p.customer_id = c.customer_id
    WHERE p.parcel_id = ?
";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $parcel_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$parcel = mysqli_fetch_assoc($result);

if (!$parcel) {
    header("Location: tracking_history.php");
    exit();
}


/* Get tracking history */
$history_sql = "
    SELECT 
        location,
        status,
        remarks,
        updated_at
    FROM tracking
    WHERE parcel_id = ?
    ORDER BY updated_at DESC
";

$history_stmt = mysqli_prepare($conn, $history_sql);
mysqli_stmt_bind_param($history_stmt, "i", $parcel_id);
mysqli_stmt_execute($history_stmt);

$history_result = mysqli_stmt_get_result($history_stmt);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>
        Tracking Details | Keystone Cargo
    </title>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f4f7fc;
            color: #222;
        }

        /* SIDEBAR */

        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: linear-gradient(180deg, #164a9c, #0b3475);
            color: white;
            padding: 30px 20px;
        }

        .logo {
            text-align: center;
            font-size: 27px;
            font-weight: bold;
            margin-bottom: 45px;
        }

        .menu a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 15px;
            margin-bottom: 8px;
            border-radius: 8px;
            font-size: 17px;
            transition: 0.3s;
        }

        .menu a:hover,
        .menu a.active {
            background: rgba(255,255,255,0.15);
            transform: translateX(5px);
        }

        .menu i {
            width: 28px;
        }

        .logout {
            margin-top: 25px;
            background: #dc3545 !important;
        }

        .logout:hover {
            background: #b02a37 !important;
        }


        /* MAIN */

        .main {
            margin-left: 260px;
            padding: 40px;
        }

        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .top h1 {
            color: #123b7a;
            font-size: 32px;
        }

        .admin {
            background: white;
            padding: 12px 20px;
            border-radius: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            color: #123b7a;
            font-weight: bold;
        }


        /* BACK BUTTON */

        .back-btn {
            display: inline-block;
            text-decoration: none;
            color: white;
            background: #165fd3;
            padding: 11px 18px;
            border-radius: 7px;
            margin-bottom: 25px;
            transition: 0.3s;
        }

        .back-btn:hover {
            background: #0d47a1;
        }


        /* CARD */

        .card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 25px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }

        .card-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .card-title h2 {
            color: #123b7a;
        }

        .tracking-number {
            background: #e7f0ff;
            color: #1261d6;
            padding: 10px 18px;
            border-radius: 25px;
            font-weight: bold;
        }


        /* DETAILS GRID */

        .details {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
        }

        .detail {
            background: #f7f9fd;
            padding: 18px;
            border-radius: 10px;
        }

        .detail label {
            display: block;
            color: #777;
            font-size: 14px;
            margin-bottom: 7px;
        }

        .detail strong {
            color: #123b7a;
            font-size: 16px;
        }


        /* STATUS */

        .status-box {
            margin-top: 20px;
            padding: 20px;
            border-left: 5px solid #16833b;
            background: #eaf8ef;
            border-radius: 8px;
        }

        .status-box span {
            display: block;
            color: #666;
            margin-bottom: 7px;
        }

        .status-box strong {
            color: #16833b;
            font-size: 21px;
        }


        /* HISTORY */

        .history {
            position: relative;
        }

        .history-item {
            position: relative;
            padding: 0 0 25px 35px;
            border-left: 2px solid #d5ddec;
            margin-left: 8px;
        }

        .history-item:last-child {
            border-left: none;
        }

        .dot {
            position: absolute;
            left: -8px;
            top: 0;
            width: 14px;
            height: 14px;
            background: #165fd3;
            border-radius: 50%;
        }

        .history-item h3 {
            color: #123b7a;
            margin-bottom: 5px;
        }

        .history-item .location {
            color: #333;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .history-item .date {
            color: #888;
            font-size: 13px;
            margin-bottom: 7px;
        }

        .history-item .remarks {
            color: #666;
            font-size: 14px;
        }

        .no-history {
            text-align: center;
            padding: 30px;
            color: #777;
        }


        /* RESPONSIVE */

        @media (max-width: 800px) {

            .sidebar {
                width: 210px;
            }

            .main {
                margin-left: 210px;
                padding: 25px;
            }

            .details {
                grid-template-columns: 1fr;
            }

            .top {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }


        @media (max-width: 600px) {

            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .main {
                margin-left: 0;
                padding: 20px;
            }

            .card-title {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }

    </style>

</head>

<body>


<!-- SIDEBAR -->

<div class="sidebar">

    <div class="logo">
        Keystone Cargo
    </div>

    <div class="menu">

        <a href="dashboard.php">
            <i class="fa-solid fa-house"></i>
            Dashboard
        </a>

        <a href="view_customer.php">
            <i class="fa-solid fa-users"></i>
            Customers
        </a>

        <a href="view_parcel.php">
            <i class="fa-solid fa-box"></i>
            Parcels
        </a>

        <a href="tracking_history.php" class="active">
            <i class="fa-solid fa-location-dot"></i>
            Tracking
        </a>

        <a href="reports.php">
            <i class="fa-solid fa-chart-column"></i>
            Reports
        </a>

        <a href="settings.php">
            <i class="fa-solid fa-gear"></i>
            Settings
        </a>

        <a href="logout.php" class="logout">
            <i class="fa-solid fa-right-from-bracket"></i>
            Logout
        </a>

    </div>

</div>


<!-- MAIN -->

<div class="main">

    <div class="top">

        <h1>
            <i class="fa-solid fa-location-dot"></i>
            Tracking Details
        </h1>

        <div class="admin">
            <i class="fa-solid fa-user"></i>

            <?php
            echo htmlspecialchars($_SESSION['admin']);
            ?>

        </div>

    </div>


    <a href="tracking_history.php" class="back-btn">

        <i class="fa-solid fa-arrow-left"></i>

        Back to Tracking History

    </a>


    <!-- PARCEL DETAILS -->

    <div class="card">

        <div class="card-title">

            <h2>
                <i class="fa-solid fa-box"></i>
                Parcel Details
            </h2>

            <div class="tracking-number">

                <?php
                echo htmlspecialchars($parcel['tracking_number']);
                ?>

            </div>

        </div>


        <div class="details">


            <div class="detail">

                <label>Sender</label>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $parcel['sender_name'] ?? 'N/A'
                    );
                    ?>
                </strong>

            </div>


            <div class="detail">

                <label>Receiver</label>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $parcel['receiver_name']
                    );
                    ?>
                </strong>

            </div>


            <div class="detail">

                <label>Sender Address</label>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $parcel['sender_address']
                    );
                    ?>
                </strong>

            </div>


            <div class="detail">

                <label>Receiver Address</label>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $parcel['receiver_address']
                    );
                    ?>
                </strong>

            </div>


            <div class="detail">

                <label>Receiver Phone</label>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $parcel['receiver_phone']
                    );
                    ?>
                </strong>

            </div>


            <div class="detail">

                <label>Parcel Type</label>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $parcel['parcel_type']
                    );
                    ?>
                </strong>

            </div>


            <div class="detail">

                <label>Weight</label>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $parcel['weight']
                    );
                    ?> kg
                </strong>

            </div>


            <div class="detail">

                <label>Booking Date</label>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $parcel['booking_date']
                    );
                    ?>
                </strong>

            </div>


            <div class="detail">

                <label>Estimated Delivery</label>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $parcel['estimated_delivery']
                    );
                    ?>
                </strong>

            </div>


            <div class="detail">

                <label>Current Status</label>

                <strong>
                    <?php
                    echo htmlspecialchars(
                        $parcel['status']
                    );
                    ?>
                </strong>

            </div>

        </div>


        <div class="status-box">

            <span>
                Current Parcel Status
            </span>

            <strong>

                <i class="fa-solid fa-truck"></i>

                <?php
                echo htmlspecialchars(
                    $parcel['status']
                );
                ?>

            </strong>

        </div>

    </div>


    <!-- TRACKING HISTORY -->

    <div class="card">

        <div class="card-title">

            <h2>
                <i class="fa-solid fa-clock-rotate-left"></i>
                Tracking History
            </h2>

        </div>


        <div class="history">

            <?php

            if (mysqli_num_rows($history_result) > 0) {

                while ($history = mysqli_fetch_assoc($history_result)) {

            ?>

                    <div class="history-item">

                        <div class="dot"></div>

                        <h3>
                            <?php
                            echo htmlspecialchars(
                                $history['status']
                            );
                            ?>
                        </h3>

                        <div class="location">

                            <i class="fa-solid fa-location-dot"></i>

                            <?php
                            echo htmlspecialchars(
                                $history['location']
                            );
                            ?>

                        </div>

                        <div class="date">

                            <i class="fa-regular fa-clock"></i>

                            <?php
                            echo htmlspecialchars(
                                $history['updated_at']
                            );
                            ?>

                        </div>

                        <?php

                        if (!empty($history['remarks'])) {

                        ?>

                            <div class="remarks">

                                <?php
                                echo htmlspecialchars(
                                    $history['remarks']
                                );
                                ?>

                            </div>

                        <?php

                        }

                        ?>

                    </div>

            <?php

                }

            } else {

            ?>

                <div class="no-history">

                    <i class="fa-solid fa-clock-rotate-left"></i>

                    <p>
                        No tracking history available for this parcel.
                    </p>

                </div>

            <?php

            }

            ?>

        </div>

    </div>

</div>

</body>

</html>