<?php
include("../includes/session.php");
include("../includes/db.php");

$id = $_GET['id'];

$parcel = mysqli_query($conn,"SELECT * FROM parcel WHERE parcel_id='$id'");
$row = mysqli_fetch_assoc($parcel);

$customers = mysqli_query($conn,"SELECT * FROM customer ORDER BY full_name");

if(isset($_POST['update']))
{
    $customer_id = $_POST['customer_id'];
    $receiver_name = $_POST['receiver_name'];
    $receiver_phone = $_POST['receiver_phone'];
    $receiver_address = $_POST['receiver_address'];
    $parcel_type = $_POST['parcel_type'];
    $weight = $_POST['weight'];
    $booking_date = $_POST['booking_date'];
    $status = $_POST['status'];
    $sender_address = $_POST['sender_address'];
    $estimated_delivery = $_POST['estimated_delivery'];

    mysqli_query($conn,"
    UPDATE parcel SET

    customer_id='$customer_id',
    receiver_name='$receiver_name',
    receiver_phone='$receiver_phone',
    receiver_address='$receiver_address',
    parcel_type='$parcel_type',
    weight='$weight',
    booking_date='$booking_date',
    status='$status',
    sender_address='$sender_address',
    estimated_delivery='$estimated_delivery'

    WHERE parcel_id='$id'
    ");

    echo "<script>
    alert('Parcel Updated Successfully');
    window.location='view_parcel.php';
    </script>";
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Edit Parcel</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f4f7fc;
font-family:Poppins;
}

.card{

max-width:900px;
margin:40px auto;

border:none;
border-radius:15px;

box-shadow:0 5px 15px rgba(0,0,0,.1);

}

.card-header{

background:#0d6efd;
color:white;
font-size:22px;
font-weight:bold;

}

</style>

</head>

<body>

<div class="card">

<div class="card-header">

Edit Parcel

</div>

<div class="card-body">

<form method="POST">

<div class="mb-3">

<label>Tracking Number</label>

<input
type="text"
class="form-control"
value="<?php echo $row['tracking_number']; ?>"
readonly>

</div>

<div class="mb-3">

<label>Customer</label>

<select
name="customer_id"
class="form-select"
required>

<?php
while($c=mysqli_fetch_assoc($customers))
{
?>

<option
value="<?php echo $c['customer_id'];?>"

<?php

if($row['customer_id']==$c['customer_id'])
echo "selected";

?>

>

<?php echo $c['full_name']; ?>

</option>

<?php } ?>

</select>

</div>

<div class="mb-3">

<label>Receiver Name</label>

<input
type="text"
name="receiver_name"
class="form-control"
value="<?php echo $row['receiver_name'];?>"
required>

</div>

<div class="mb-3">

<label>Receiver Phone</label>

<input
type="text"
name="receiver_phone"
class="form-control"
value="<?php echo $row['receiver_phone'];?>"
required>

</div>

<div class="mb-3">

<label>Receiver Address</label>

<textarea
name="receiver_address"
class="form-control"
rows="3"><?php echo $row['receiver_address'];?></textarea>

</div>

<div class="row">

<div class="col-md-6">

<label>Parcel Type</label>

<input
type="text"
name="parcel_type"
class="form-control"
value="<?php echo $row['parcel_type'];?>">

</div>

<div class="col-md-6">

<label>Weight</label>

<input
type="number"
step="0.01"
name="weight"
class="form-control"
value="<?php echo $row['weight'];?>">

</div>

</div>

<br>

<div class="mb-3">

<label>Sender Address</label>

<textarea
name="sender_address"
class="form-control"
rows="3"><?php echo $row['sender_address'];?></textarea>

</div>

<div class="row">

<div class="col-md-6">

<label>Booking Date</label>

<input
type="date"
name="booking_date"
class="form-control"
value="<?php echo $row['booking_date'];?>">

</div>

<div class="col-md-6">

<label>Estimated Delivery</label>

<input
type="date"
name="estimated_delivery"
class="form-control"
value="<?php echo $row['estimated_delivery'];?>">

</div>

</div>

<br>

<div class="mb-3">

<label>Status</label>

<select
name="status"
class="form-select">

<option <?php if($row['status']=="Booked") echo "selected"; ?>>Booked</option>

<option <?php if($row['status']=="In Transit") echo "selected"; ?>>In Transit</option>

<option <?php if($row['status']=="Out for Delivery") echo "selected"; ?>>Out for Delivery</option>

<option <?php if($row['status']=="Delivered") echo "selected"; ?>>Delivered</option>

</select>

</div>

<button
class="btn btn-success"
name="update">

Update Parcel

</button>

<a
href="view_parcel.php"
class="btn btn-secondary">

Cancel

</a>

</form>

</div>

</div>

</body>

</html>