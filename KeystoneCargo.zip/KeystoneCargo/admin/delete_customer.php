<?php
session_start();

include("../includes/db.php");

/* Check admin login */
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

/* Check customer ID */
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: view_customer.php");
    exit();
}

$customer_id = intval($_GET['id']);

/* Check whether customer exists */
$check_sql = "SELECT customer_id FROM customer WHERE customer_id = ?";

$check_stmt = mysqli_prepare($conn, $check_sql);

mysqli_stmt_bind_param(
    $check_stmt,
    "i",
    $customer_id
);

mysqli_stmt_execute($check_stmt);

$check_result = mysqli_stmt_get_result($check_stmt);

if (mysqli_num_rows($check_result) == 0) {

    mysqli_stmt_close($check_stmt);

    header("Location: view_customer.php?error=notfound");
    exit();
}

mysqli_stmt_close($check_stmt);


/*
   Check whether this customer has parcels.
   Because parcel.customer_id is a foreign key,
   deleting the customer while parcels exist may fail.
*/

$parcel_sql = "SELECT COUNT(*) AS total FROM parcel WHERE customer_id = ?";

$parcel_stmt = mysqli_prepare($conn, $parcel_sql);

mysqli_stmt_bind_param(
    $parcel_stmt,
    "i",
    $customer_id
);

mysqli_stmt_execute($parcel_stmt);

$parcel_result = mysqli_stmt_get_result($parcel_stmt);

$parcel_data = mysqli_fetch_assoc($parcel_result);

mysqli_stmt_close($parcel_stmt);


/* If customer has parcels, do not delete */
if ($parcel_data['total'] > 0) {

    header("Location: view_customer.php?error=hasparcels");
    exit();
}


/* Delete customer */
$delete_sql = "DELETE FROM customer WHERE customer_id = ?";

$delete_stmt = mysqli_prepare($conn, $delete_sql);

mysqli_stmt_bind_param(
    $delete_stmt,
    "i",
    $customer_id
);

if (mysqli_stmt_execute($delete_stmt)) {

    mysqli_stmt_close($delete_stmt);

    header("Location: view_customer.php?deleted=1");
    exit();

} else {

    mysqli_stmt_close($delete_stmt);

    header("Location: view_customer.php?error=deletefailed");
    exit();
}
?>