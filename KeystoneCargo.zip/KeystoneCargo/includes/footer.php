<!-- =========================================================
     KEYSTONE CARGO FOOTER
     ========================================================= -->

<footer class="kc-footer">

    <div class="kc-footer-container">

        <div class="kc-footer-brand">

            <div class="kc-footer-logo">
                <span class="kc-footer-logo-box"></span>
            </div>

            <div>

                <h3>
                    Keystone Cargo
                </h3>

                <p>
                    Reliable parcel tracking and delivery management.
                </p>

            </div>

        </div>


        <div class="kc-footer-links">

            <a href="/KeystoneCargo/index.php">
                Home
            </a>

            <a href="/KeystoneCargo/about.php">
                About
            </a>

            <a href="/KeystoneCargo/services.php">
                Services
            </a>

            <a href="/KeystoneCargo/track.php">
                Track Parcel
            </a>

            <a href="/KeystoneCargo/contact.php">
                Contact
            </a>

        </div>

    </div>


    <div class="kc-footer-bottom">

        © <?php echo date("Y"); ?> Keystone Cargo.
        All Rights Reserved.

    </div>

</footer>