<?php
include("includes/header.php");
include("includes/navbar.php");
?>

<style>

/* ================= HOME HERO ================= */

.home-hero {
    min-height: 650px;

    display: flex;
    align-items: center;

    background:
        linear-gradient(
            135deg,
            #eef5ff,
            #ffffff
        );

    padding: 90px 20px 70px;
}

.home-container {
    width: 92%;
    max-width: 1150px;
    margin: auto;
}

.home-grid {
    display: grid;
    grid-template-columns: 1.2fr 0.8fr;
    gap: 50px;
    align-items: center;
}


/* ================= HERO TEXT ================= */

.hero-content h1 {
    color: #003f88;

    font-size: 52px;

    font-weight: 800;

    line-height: 1.15;

    margin-bottom: 20px;
}

.hero-content h1 span {
    color: #0d6efd;
}

.hero-content p {
    color: #666;

    font-size: 17px;

    line-height: 1.8;

    max-width: 620px;

    margin-bottom: 30px;
}


/* ================= HERO BUTTONS ================= */

.hero-buttons {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
}

.hero-button {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    gap: 8px;

    padding: 13px 25px;

    border-radius: 30px;

    text-decoration: none;

    font-weight: 600;

    transition: 0.3s;
}

.primary-button {
    background: #0d6efd;
    color: white;
}

.primary-button:hover {
    background: #003f88;
    color: white;

    transform: translateY(-3px);

    box-shadow:
        0 8px 20px
        rgba(13,110,253,0.25);
}

.secondary-button {
    border: 2px solid #0d6efd;
    color: #0d6efd;
    background: white;
}

.secondary-button:hover {
    background: #0d6efd;
    color: white;

    transform: translateY(-3px);
}


/* ================= HERO VISUAL ================= */

.hero-visual {
    display: flex;

    align-items: center;
    justify-content: center;
}

.cargo-card {
    width: 100%;
    max-width: 400px;

    padding: 45px 30px;

    background: white;

    border-radius: 25px;

    text-align: center;

    box-shadow:
        0 20px 50px
        rgba(0,0,0,0.10);

    border: 1px solid #e6edf7;
}

.cargo-icon {
    width: 120px;
    height: 120px;

    margin: auto auto 25px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 30px;

    background:
        linear-gradient(
            135deg,
            #0d6efd,
            #003f88
        );

    color: white;

    font-size: 55px;

    box-shadow:
        0 12px 25px
        rgba(13,110,253,0.25);
}

.cargo-card h3 {
    color: #003f88;

    font-size: 26px;

    font-weight: 700;

    margin-bottom: 10px;
}

.cargo-card p {
    color: #777;

    margin: 0;
}


/* ================= TRACK BOX ================= */

.quick-track {
    margin-top: -45px;

    position: relative;

    z-index: 5;

    padding: 0 20px;
}

.quick-track-container {
    max-width: 900px;

    margin: auto;

    background: white;

    padding: 25px;

    border-radius: 18px;

    box-shadow:
        0 15px 40px
        rgba(0,0,0,0.12);
}

.quick-track-form {
    display: grid;

    grid-template-columns: 1fr auto;

    gap: 12px;
}

.quick-track-form input {
    width: 100%;

    padding: 14px 17px;

    border: 1px solid #d6dfeb;

    border-radius: 10px;

    font-family: 'Poppins', sans-serif;
}

.quick-track-form input:focus {
    outline: none;

    border-color: #0d6efd;

    box-shadow:
        0 0 0 3px
        rgba(13,110,253,0.1);
}

.quick-track-form button {
    border: none;

    padding: 14px 25px;

    border-radius: 10px;

    background: #0d6efd;

    color: white;

    font-weight: 600;

    cursor: pointer;

    transition: 0.3s;
}

.quick-track-form button:hover {
    background: #003f88;

    transform: translateY(-2px);
}


/* ================= FEATURES ================= */

.features-section {
    padding: 100px 20px 70px;

    background: white;
}

.section-container {
    max-width: 1150px;

    margin: auto;
}

.section-title {
    text-align: center;

    color: #003f88;

    font-weight: 700;

    margin-bottom: 12px;
}

.section-subtitle {
    text-align: center;

    color: #777;

    max-width: 700px;

    margin: 0 auto 45px;
}

.feature-grid {
    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 25px;
}

.home-feature {
    padding: 30px;

    text-align: center;

    background: #f7faff;

    border-radius: 16px;

    border: 1px solid #e6edf7;

    transition: 0.3s;
}

.home-feature:hover {
    transform: translateY(-7px);

    box-shadow:
        0 15px 30px
        rgba(0,0,0,0.08);
}

.home-feature i {
    font-size: 38px;

    color: #0d6efd;

    margin-bottom: 18px;
}

.home-feature h3 {
    color: #003f88;

    font-size: 20px;

    margin-bottom: 10px;
}

.home-feature p {
    color: #777;

    line-height: 1.7;

    margin: 0;
}


/* ================= HOW IT WORKS ================= */

.how-section {
    padding: 80px 20px;

    background: #f5f8fc;
}

.steps-grid {
    max-width: 1050px;

    margin: auto;

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 20px;
}

.step {
    text-align: center;
}

.step-number {
    width: 60px;
    height: 60px;

    margin: auto auto 18px;

    display: flex;
    align-items: center;
    justify-content: center;

    background: #0d6efd;

    color: white;

    border-radius: 50%;

    font-size: 21px;

    font-weight: 700;
}

.step h4 {
    color: #003f88;

    font-size: 18px;

    margin-bottom: 8px;
}

.step p {
    color: #777;

    font-size: 14px;

    line-height: 1.6;
}


/* ================= CTA ================= */

.home-cta {
    padding: 75px 20px;

    text-align: center;

    background:
        linear-gradient(
            135deg,
            #0d6efd,
            #003f88
        );

    color: white;
}

.home-cta h2 {
    font-weight: 700;

    margin-bottom: 12px;
}

.home-cta p {
    opacity: 0.9;

    margin-bottom: 25px;
}

.cta-button {
    display: inline-block;

    padding: 13px 28px;

    background: white;

    color: #003f88;

    border-radius: 30px;

    text-decoration: none;

    font-weight: 700;

    transition: 0.3s;
}

.cta-button:hover {
    transform: translateY(-3px);

    color: #0d6efd;

    box-shadow:
        0 8px 20px
        rgba(0,0,0,0.15);
}


/* ================= RESPONSIVE ================= */

@media (max-width: 850px) {

    .home-grid {
        grid-template-columns: 1fr;

        text-align: center;
    }

    .hero-content p {
        margin-left: auto;
        margin-right: auto;
    }

    .hero-buttons {
        justify-content: center;
    }

    .hero-content h1 {
        font-size: 42px;
    }

    .feature-grid {
        grid-template-columns: 1fr 1fr;
    }

    .steps-grid {
        grid-template-columns: 1fr 1fr;
        row-gap: 35px;
    }

}


@media (max-width: 600px) {

    .home-hero {
        min-height: auto;

        padding-top: 70px;
    }

    .hero-content h1 {
        font-size: 34px;
    }

    .hero-content p {
        font-size: 15px;
    }

    .feature-grid {
        grid-template-columns: 1fr;
    }

    .steps-grid {
        grid-template-columns: 1fr;
    }

    .quick-track-form {
        grid-template-columns: 1fr;
    }

    .quick-track-form button {
        width: 100%;
    }

}

</style>


<!-- =====================================================
     HERO
===================================================== -->

<section class="home-hero">

    <div class="home-container">

        <div class="home-grid">


            <!-- HERO TEXT -->

            <div class="hero-content">

                <h1>

                    Delivering Your
                    <span>Trust</span>
                    Safely

                </h1>

                <p>

                    Keystone Cargo provides a simple and
                    reliable way to manage parcels and track
                    shipments from booking to final delivery.

                </p>


                <div class="hero-buttons">

                    <a
                        href="track.php"
                        class="hero-button primary-button"
                    >

                        <i class="fas fa-location-crosshairs"></i>

                        Track Parcel

                    </a>


                    <a
                        href="services.php"
                        class="hero-button secondary-button"
                    >

                        <i class="fas fa-box"></i>

                        Our Services

                    </a>

                </div>

            </div>


            <!-- HERO VISUAL -->

            <div class="hero-visual">

                <div class="cargo-card">

                    <div class="cargo-icon">

                        <i class="fas fa-truck-fast"></i>

                    </div>

                    <h3>
                        Keystone Cargo
                    </h3>

                    <p>
                        Reliable. Secure. Delivered.
                    </p>

                </div>

            </div>


        </div>

    </div>

</section>


<!-- =====================================================
     QUICK TRACK
===================================================== -->

<section class="quick-track">

    <div class="quick-track-container">

        <form
            action="track.php"
            method="POST"
            class="quick-track-form"
        >

            <input
                type="text"
                name="tracking_number"
                placeholder="Enter your tracking number — Example: CTS0003"
                required
            >

            <button
                type="submit"
                name="track"
            >

                <i class="fas fa-search"></i>

                Track Now

            </button>

        </form>

    </div>

</section>


<!-- =====================================================
     FEATURES
===================================================== -->

<section class="features-section">

    <div class="section-container">

        <h2 class="section-title">
            Why Choose Keystone Cargo?
        </h2>

        <p class="section-subtitle">

            Everything you need to manage and track
            your parcel journey with confidence.

        </p>


        <div class="feature-grid">


            <div class="home-feature">

                <i class="fas fa-location-dot"></i>

                <h3>
                    Easy Tracking
                </h3>

                <p>
                    Enter your tracking number and
                    quickly view your parcel journey.
                </p>

            </div>


            <div class="home-feature">

                <i class="fas fa-shield-halved"></i>

                <h3>
                    Secure System
                </h3>

                <p>
                    Customer and parcel information
                    is managed through a structured system.
                </p>

            </div>


            <div class="home-feature">

                <i class="fas fa-route"></i>

                <h3>
                    Full Journey
                </h3>

                <p>
                    Follow parcel updates from booking
                    through delivery.
                </p>

            </div>


        </div>

    </div>

</section>


<!-- =====================================================
     HOW IT WORKS
===================================================== -->

<section class="how-section">

    <div class="section-container">

        <h2 class="section-title">
            How It Works
        </h2>

        <p class="section-subtitle">
            A simple process for managing and tracking
            your parcel.
        </p>


        <div class="steps-grid">


            <div class="step">

                <div class="step-number">
                    1
                </div>

                <h4>
                    Book
                </h4>

                <p>
                    Parcel information is registered.
                </p>

            </div>


            <div class="step">

                <div class="step-number">
                    2
                </div>

                <h4>
                    Pack
                </h4>

                <p>
                    The parcel is prepared for shipment.
                </p>

            </div>


            <div class="step">

                <div class="step-number">
                    3
                </div>

                <h4>
                    Track
                </h4>

                <p>
                    Follow the parcel's movement.
                </p>

            </div>


            <div class="step">

                <div class="step-number">
                    4
                </div>

                <h4>
                    Deliver
                </h4>

                <p>
                    Parcel reaches the receiver.
                </p>

            </div>


        </div>

    </div>

</section>


<!-- =====================================================
     CTA
===================================================== -->

<section class="home-cta">

    <h2>
        Ready to Track Your Parcel?
    </h2>

    <p>
        Enter your tracking number and see
        the latest available shipment update.
    </p>

    <a
        href="track.php"
        class="cta-button"
    >

        <i class="fas fa-location-crosshairs"></i>

        Track Parcel

    </a>

</section>


<?php
include("includes/footer.php");
?>