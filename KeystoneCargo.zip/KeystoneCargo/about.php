<?php

include("includes/header.php");

include("includes/navbar.php");

?>


<!-- =========================================================
     ABOUT HERO
     ========================================================= -->

<section class="kc-about-hero">

    <div class="kc-about-container">


        <!-- LOGO ICON -->

        <div class="kc-about-icon">

            <div class="kc-about-package">

                <div class="kc-about-package-top"></div>

                <div class="kc-about-package-body"></div>

            </div>

        </div>


        <!-- TITLE -->

        <h1 class="kc-about-title">

            About
            <span>Keystone Cargo</span>

        </h1>


        <!-- DESCRIPTION -->

        <p class="kc-about-description">

            Keystone Cargo is a professional parcel tracking
            and delivery management system designed to make
            courier operations simple, organized and reliable.

        </p>


        <!-- CARDS -->

        <div class="kc-about-cards">


            <!-- CARD 1 -->

            <div class="kc-about-card">

                <div class="kc-card-icon">
                    <i class="fa-solid fa-box"></i>
                </div>

                <h3>
                    Easy Parcel Management
                </h3>

                <p>

                    Manage customer information, parcel bookings,
                    delivery details and parcel status from one
                    centralized system.

                </p>

            </div>


            <!-- CARD 2 -->

            <div class="kc-about-card">

                <div class="kc-card-icon">
                    <i class="fa-solid fa-truck-fast"></i>
                </div>

                <h3>
                    Real-Time Tracking
                </h3>

                <p>

                    Customers can enter their tracking number
                    and easily view the current delivery status
                    of their parcel.

                </p>

            </div>


            <!-- CARD 3 -->

            <div class="kc-about-card">

                <div class="kc-card-icon">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>

                <h3>
                    Secure Administration
                </h3>

                <p>

                    Administrators can manage customers,
                    parcels and tracking information through
                    a dedicated administration panel.

                </p>

            </div>


        </div>

    </div>

</section>


<?php

include("includes/footer.php");

?>