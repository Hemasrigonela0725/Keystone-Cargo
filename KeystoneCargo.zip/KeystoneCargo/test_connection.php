<?php
include("includes/db.php");

echo "<h2 style='color:green;text-align:center;margin-top:100px;'>
Database Connected Successfully!
</h2>";
?>