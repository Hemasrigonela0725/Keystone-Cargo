/* =========================================================
   KEYSTONE CARGO - MAIN JAVASCRIPT
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {

    /* ================= MOBILE NAVBAR ================= */

    const menuToggle = document.getElementById("menuToggle");
    const navLinks = document.getElementById("navLinks");

    if (menuToggle && navLinks) {

        menuToggle.addEventListener("click", function () {

            navLinks.classList.toggle("show");

        });


        /* Close menu after clicking a link */

        const links = navLinks.querySelectorAll("a");

        links.forEach(function (link) {

            link.addEventListener("click", function () {

                navLinks.classList.remove("show");

            });

        });

    }


    /* ================= SMOOTH SCROLL ================= */

    const anchors = document.querySelectorAll(
        'a[href^="#"]'
    );

    anchors.forEach(function (anchor) {

        anchor.addEventListener("click", function (event) {

            const targetId =
                this.getAttribute("href");

            if (
                targetId &&
                targetId !== "#"
            ) {

                const target =
                    document.querySelector(targetId);

                if (target) {

                    event.preventDefault();

                    target.scrollIntoView({
                        behavior: "smooth",
                        block: "start"
                    });

                }

            }

        });

    });


    /* ================= NAVBAR SCROLL ================= */

    const navbar =
        document.querySelector(".navbar");

    if (navbar) {

        window.addEventListener("scroll", function () {

            if (window.scrollY > 30) {

                navbar.classList.add(
                    "navbar-scrolled"
                );

            } else {

                navbar.classList.remove(
                    "navbar-scrolled"
                );

            }

        });

    }


    /* ================= AUTO HIDE ALERTS ================= */

    const alerts =
        document.querySelectorAll(
            ".alert"
        );

    alerts.forEach(function (alert) {

        setTimeout(function () {

            alert.style.opacity = "0";

            alert.style.transform =
                "translateY(-10px)";

            setTimeout(function () {

                alert.remove();

            }, 400);

        }, 5000);

    });


    /* ================= CONFIRM DELETE ================= */

    const deleteButtons =
        document.querySelectorAll(
            ".delete-btn"
        );

    deleteButtons.forEach(function (button) {

        button.addEventListener(
            "click",
            function (event) {

                const confirmed =
                    confirm(
                        "Are you sure you want to delete this record?"
                    );

                if (!confirmed) {

                    event.preventDefault();

                }

            }
        );

    });


    /* ================= CURRENT YEAR ================= */

    const yearElements =
        document.querySelectorAll(
            ".current-year"
        );

    yearElements.forEach(function (element) {

        element.textContent =
            new Date().getFullYear();

    });

});