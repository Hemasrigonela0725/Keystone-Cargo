<?php
include("includes/db.php");

$tracking_number = "";
$parcel = null;
$history = [];
$error = "";

/* =========================================================
   GET TRACKING NUMBER
========================================================= */

if (isset($_GET['tracking_number'])) {
    $tracking_number = trim($_GET['tracking_number']);
}

/* =========================================================
   FETCH PARCEL
========================================================= */

if ($tracking_number != "") {

    $sql = "
        SELECT
            p.parcel_id,
            p.tracking_number,
            p.customer_id,
            p.receiver_name,
            p.receiver_phone,
            p.receiver_address,
            p.parcel_type,
            p.weight,
            p.booking_date,
            p.status,
            p.sender_address,
            p.estimated_delivery,

            c.full_name AS sender_name,
            c.phone AS sender_phone,
            c.email AS sender_email,
            c.address AS sender_address_customer

        FROM parcel p

        LEFT JOIN customer c
            ON p.customer_id = c.customer_id

        WHERE p.tracking_number = ?

        LIMIT 1
    ";

    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {

        mysqli_stmt_bind_param(
            $stmt,
            "s",
            $tracking_number
        );

        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0) {

            $parcel = mysqli_fetch_assoc($result);

            /* =================================================
               FETCH TRACKING HISTORY
            ================================================= */

            $history_sql = "
                SELECT
                    history_id,
                    parcel_id,
                    location,
                    status,
                    remarks,
                    updated_at
                FROM tracking_history
                WHERE parcel_id = ?
                ORDER BY updated_at ASC, history_id ASC
            ";

            $history_stmt = mysqli_prepare(
                $conn,
                $history_sql
            );

            if ($history_stmt) {

                mysqli_stmt_bind_param(
                    $history_stmt,
                    "i",
                    $parcel['parcel_id']
                );

                mysqli_stmt_execute(
                    $history_stmt
                );

                $history_result =
                    mysqli_stmt_get_result(
                        $history_stmt
                    );

                if ($history_result) {

                    while (
                        $row =
                        mysqli_fetch_assoc(
                            $history_result
                        )
                    ) {

                        $history[] = $row;
                    }
                }

                mysqli_stmt_close(
                    $history_stmt
                );
            }

        } else {

            $error =
                "No parcel found with tracking number "
                . htmlspecialchars($tracking_number);
        }

        mysqli_stmt_close($stmt);

    } else {

        $error = "Unable to process the tracking request.";
    }
}


/* =========================================================
   HELPER FUNCTIONS
========================================================= */

function clean($value)
{
    return htmlspecialchars(
        $value ?? "",
        ENT_QUOTES,
        "UTF-8"
    );
}


function getStatusIcon($status)
{
    $status = strtolower(trim($status));

    switch ($status) {

        case "booked":
            return "fa-clipboard-check";

        case "packed":
            return "fa-box";

        case "in transit":
            return "fa-truck";

        case "out for delivery":
            return "fa-location-dot";

        case "delivered":
            return "fa-house-circle-check";

        default:
            return "fa-box-open";
    }
}


function getStatusClass($status)
{
    $status = strtolower(trim($status));

    switch ($status) {

        case "booked":
            return "booked";

        case "packed":
            return "packed";

        case "in transit":
            return "transit";

        case "out for delivery":
            return "out";

        case "delivered":
            return "delivered";

        default:
            return "default";
    }
}


function formatDateTime($date)
{
    if (!$date) {
        return "";
    }

    return date(
        "d M Y • h:i A",
        strtotime($date)
    );
}


function formatDateOnly($date)
{
    if (!$date) {
        return "";
    }

    return date(
        "d M Y",
        strtotime($date)
    );
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Track Parcel | Keystone Cargo
    </title>

    <!-- Font Awesome -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <!-- Google Font -->
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet"
    >
    <!--Keystone Cargo CSS-->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/tracking.css">

<style>

/* =========================================================
   RESET
========================================================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: 'Poppins', sans-serif;
    background: #f4f8ff;
    color: #173f70;
}


/* =========================================================
   NAVBAR
========================================================= */

.kc-navbar {

    width: 100%;

    height: 92px;

    background: rgba(255,255,255,0.97);

    border-bottom: 1px solid #e3edf9;

    display: flex;

    align-items: center;

    position: sticky;

    top: 0;

    z-index: 1000;

    box-shadow:
        0 4px 20px rgba(28,76,130,0.06);
}

.kc-nav-container {

    width: 92%;

    max-width: 1450px;

    margin: auto;

    display: flex;

    align-items: center;

    justify-content: space-between;
}


/* Brand */

.kc-brand {

    display: flex;

    align-items: center;

    gap: 15px;

    text-decoration: none;
}

.kc-logo {

    width: 52px;

    height: 52px;

    background: #1469df;

    border-radius: 15px;

    display: flex;

    align-items: center;

    justify-content: center;

    color: white;

    font-size: 22px;

    box-shadow:
        0 8px 20px rgba(20,105,223,0.22);
}

.kc-brand-name {

    font-size: 24px;

    font-weight: 800;

    color: #153f75;

    letter-spacing: -0.5px;
}


/* Navigation */

.kc-nav-links {

    display: flex;

    align-items: center;

    gap: 38px;
}

.kc-nav-links a {

    text-decoration: none;

    color: #45688f;

    font-size: 16px;

    font-weight: 600;

    transition: 0.25s ease;
}

.kc-nav-links a:hover {

    color: #1469df;
}


/* Admin */

.kc-admin {

    background: #1469df !important;

    color: white !important;

    padding: 13px 22px;

    border-radius: 14px;

    box-shadow:
        0 8px 20px rgba(20,105,223,0.20);
}

.kc-admin:hover {

    background: #0e58bf !important;

    transform: translateY(-2px);
}


/* =========================================================
   MAIN
========================================================= */

.track-page {

    width: 100%;

    min-height: calc(100vh - 92px);

    padding: 55px 20px 80px;

    background:

        radial-gradient(
            circle at 10% 10%,
            rgba(43,124,238,0.12),
            transparent 30%
        ),

        radial-gradient(
            circle at 90% 70%,
            rgba(43,124,238,0.09),
            transparent 30%
        ),

        #f4f8ff;
}

.track-container {

    width: 92%;

    max-width: 1400px;

    margin: auto;
}


/* =========================================================
   BACK BUTTON
========================================================= */

.back-home {

    display: inline-flex;

    align-items: center;

    gap: 9px;

    text-decoration: none;

    background: white;

    color: #275783;

    padding: 12px 19px;

    border-radius: 12px;

    border: 1px solid #dce9f8;

    font-size: 14px;

    font-weight: 600;

    box-shadow:
        0 5px 18px rgba(35,78,125,0.06);

    transition: 0.25s ease;

    margin-bottom: 30px;
}

.back-home:hover {

    color: #1469df;

    border-color: #b9d4f5;

    transform: translateX(-3px);
}


/* =========================================================
   SEARCH CARD
========================================================= */

.search-card {

    background: white;

    border-radius: 25px;

    padding: 45px;

    text-align: center;

    border: 1px solid #e0ebf9;

    box-shadow:
        0 18px 50px rgba(34,80,130,0.08);

    margin-bottom: 35px;
}

.search-icon {

    width: 68px;

    height: 68px;

    margin: 0 auto 18px;

    border-radius: 18px;

    background: #eaf3ff;

    color: #1469df;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 27px;
}

.search-card h1 {

    font-size: 35px;

    color: #123f78;

    font-weight: 800;

    margin-bottom: 9px;
}

.search-card p {

    color: #7a91ad;

    font-size: 15px;

    margin-bottom: 30px;
}

.search-form {

    max-width: 800px;

    margin: auto;

    display: flex;

    gap: 12px;
}

.search-input {

    flex: 1;

    height: 58px;

    border: 1px solid #d5e4f6;

    border-radius: 14px;

    padding: 0 20px;

    outline: none;

    color: #234b78;

    font-family: inherit;

    font-size: 15px;

    background: #f9fbff;

    transition: 0.25s;
}

.search-input:focus {

    border-color: #1469df;

    background: white;

    box-shadow:
        0 0 0 4px rgba(20,105,223,0.08);
}

.track-btn {

    height: 58px;

    border: none;

    border-radius: 14px;

    background: #1469df;

    color: white;

    padding: 0 27px;

    font-family: inherit;

    font-size: 15px;

    font-weight: 700;

    cursor: pointer;

    display: flex;

    align-items: center;

    gap: 9px;

    box-shadow:
        0 8px 20px rgba(20,105,223,0.20);

    transition: 0.25s;
}

.track-btn:hover {

    background: #0d59c4;

    transform: translateY(-2px);
}


/* =========================================================
   ERROR
========================================================= */

.error-card {

    background: #fff7f7;

    border: 1px solid #ffd4d4;

    color: #b42318;

    padding: 20px 25px;

    border-radius: 15px;

    margin-bottom: 30px;

    display: flex;

    align-items: center;

    gap: 12px;

    font-size: 14px;

    font-weight: 600;
}


/* =========================================================
   PARCEL RESULT
========================================================= */

.result-card {

    background: white;

    border-radius: 28px;

    padding: 40px;

    border: 1px solid #dfebf9;

    box-shadow:
        0 18px 55px rgba(30,78,130,0.08);
}


/* Header */

.result-header {

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding-bottom: 28px;

    border-bottom: 1px solid #e5edf7;

    margin-bottom: 30px;
}

.tracking-label {

    color: #8299b2;

    font-size: 12px;

    font-weight: 700;

    letter-spacing: 2px;

    margin-bottom: 5px;
}

.tracking-number {

    color: #123f78;

    font-size: 34px;

    font-weight: 800;

    letter-spacing: 1px;
}

.current-status {

    display: inline-flex;

    align-items: center;

    gap: 9px;

    padding: 12px 19px;

    border-radius: 30px;

    background: #eaf3ff;

    color: #1469df;

    font-size: 14px;

    font-weight: 700;
}

.status-dot {

    width: 9px;

    height: 9px;

    border-radius: 50%;

    background: #1469df;
}


/* =========================================================
   INFO CARDS
========================================================= */

.info-grid {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 20px;

    margin-bottom: 60px;
}

.info-card {

    background: #f7faff;

    border: 1px solid #dce9f8;

    border-radius: 19px;

    padding: 27px;

    min-height: 175px;

    transition: 0.25s ease;
}

.info-card:hover {

    transform: translateY(-3px);

    box-shadow:
        0 10px 28px rgba(36,89,145,0.08);
}

.info-icon {

    width: 42px;

    height: 42px;

    background: #e8f2ff;

    color: #1469df;

    border-radius: 12px;

    display: flex;

    align-items: center;

    justify-content: center;

    margin-bottom: 15px;
}

.info-title {

    color: #7b94b0;

    font-size: 13px;

    font-weight: 600;

    margin-bottom: 8px;
}

.info-name {

    color: #153f75;

    font-size: 21px;

    font-weight: 800;

    margin-bottom: 5px;
}

.info-text {

    color: #7890ad;

    font-size: 14px;

    line-height: 1.7;
}


/* =========================================================
   DELIVERY JOURNEY
========================================================= */

.journey-section {

    margin-top: 10px;

    padding-top: 10px;
}

.journey-heading {

    text-align: center;

    margin-bottom: 40px;
}

.journey-label {

    display: block;

    color: #7e96b2;

    font-size: 12px;

    font-weight: 700;

    letter-spacing: 2px;

    margin-bottom: 7px;
}

.journey-heading h2 {

    color: #123f78;

    font-size: 34px;

    font-weight: 800;

    margin-bottom: 8px;
}

.journey-heading p {

    color: #7890ad;

    font-size: 15px;
}


/* Timeline */

.journey-timeline {

    width: 94%;

    max-width: 1100px;

    margin: auto;

    position: relative;

    padding: 5px 0 5px 0;
}


/* Vertical line */

.journey-timeline::before {

    content: "";

    position: absolute;

    left: 29px;

    top: 30px;

    bottom: 30px;

    width: 3px;

    border-radius: 10px;

    background:
        linear-gradient(
            to bottom,
            #1469df,
            #9bc5f5
        );
}


/* Journey item */

.journey-item {

    position: relative;

    display: flex;

    align-items: flex-start;

    gap: 25px;

    margin-bottom: 25px;
}

.journey-item:last-child {

    margin-bottom: 0;
}


/* Icon */

.journey-icon {

    position: relative;

    z-index: 3;

    width: 60px;

    height: 60px;

    min-width: 60px;

    border-radius: 50%;

    background: #1469df;

    color: white;

    border: 6px solid #edf5ff;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 20px;

    box-shadow:
        0 7px 20px rgba(20,105,223,0.22);
}


/* Journey content */

.journey-content {

    flex: 1;

    background: white;

    border: 1px solid #dce8f7;

    border-radius: 17px;

    padding: 20px 24px;

    box-shadow:
        0 5px 20px rgba(40,88,135,0.04);

    transition: 0.25s ease;
}

.journey-content:hover {

    border-color: #b9d4f5;

    box-shadow:
        0 10px 28px rgba(40,88,135,0.09);

    transform: translateX(4px);
}


/* Status */

.journey-status {

    color: #163f74;

    font-size: 19px;

    font-weight: 800;

    margin-bottom: 8px;

    display: flex;

    align-items: center;

    gap: 8px;
}


/* Date time */

.journey-date {

    color: #607e9e;

    font-size: 13px;

    font-weight: 600;

    display: flex;

    align-items: center;

    gap: 8px;

    margin-bottom: 10px;
}

.journey-date i {

    color: #1469df;
}


/* Update */

.journey-update {

    color: #637e9d;

    font-size: 14px;

    line-height: 1.6;

    display: flex;

    gap: 8px;

    align-items: flex-start;
}

.journey-update i {

    color: #1469df;

    margin-top: 4px;
}


/* =========================================================
   EMPTY JOURNEY
========================================================= */

.journey-empty {

    max-width: 1050px;

    margin: auto;

    padding: 45px 25px;

    text-align: center;

    background: #f8fbff;

    border: 1px dashed #b9d5f5;

    border-radius: 18px;
}

.empty-icon {

    width: 58px;

    height: 58px;

    margin: 0 auto 15px;

    border-radius: 50%;

    background: #eaf3ff;

    color: #1469df;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 21px;
}

.journey-empty h3 {

    color: #234c7e;

    font-size: 18px;

    margin-bottom: 7px;
}

.journey-empty p {

    color: #7c93ad;

    font-size: 14px;
}


/* =========================================================
   PARCEL DETAILS
========================================================= */

.details-section {

    margin-top: 60px;

    padding-top: 35px;

    border-top: 1px solid #e4edf7;
}

.details-title {

    color: #123f78;

    font-size: 25px;

    font-weight: 800;

    margin-bottom: 22px;
}

.details-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 14px;
}

.detail-row {

    background: #f7faff;

    border: 1px solid #e3edf8;

    border-radius: 13px;

    padding: 18px 21px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 20px;
}

.detail-name {

    color: #7890ad;

    font-size: 14px;
}

.detail-value {

    color: #153f75;

    font-size: 15px;

    font-weight: 700;

    text-align: right;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {

    .kc-nav-links {

        gap: 18px;
    }

    .info-grid {

        grid-template-columns: 1fr;
    }

    .details-grid {

        grid-template-columns: 1fr;
    }
}


@media (max-width: 700px) {

    .kc-navbar {

        height: auto;

        padding: 15px 0;
    }

    .kc-nav-container {

        flex-direction: column;

        gap: 15px;
    }

    .kc-nav-links {

        flex-wrap: wrap;

        justify-content: center;

        gap: 15px;
    }

    .kc-brand-name {

        font-size: 21px;
    }

    .track-page {

        padding: 30px 10px 50px;
    }

    .search-card {

        padding: 30px 20px;
    }

    .search-card h1 {

        font-size: 28px;
    }

    .search-form {

        flex-direction: column;
    }

    .track-btn {

        justify-content: center;
    }

    .result-card {

        padding: 22px 16px;
    }

    .result-header {

        flex-direction: column;

        align-items: flex-start;

        gap: 18px;
    }

    .tracking-number {

        font-size: 28px;
    }

    .journey-heading h2 {

        font-size: 28px;
    }

    .journey-timeline {

        width: 100%;
    }

    .journey-timeline::before {

        left: 25px;
    }

    .journey-item {

        gap: 15px;
    }

    .journey-icon {

        width: 52px;

        height: 52px;

        min-width: 52px;

        font-size: 17px;

        border-width: 5px;
    }

    .journey-content {

        padding: 16px;
    }

    .journey-status {

        font-size: 16px;
    }

    .journey-date {

        font-size: 12px;
    }

    .journey-update {

        font-size: 13px;
    }
}
/* =========================================================
   FINAL GLASS DESIGN - KEYSTONE CARGO
   ========================================================= */

/* Bright warehouse background */
body {
    background:
        linear-gradient(
            rgba(255, 255, 255, 0),
            rgba(255, 255, 255, 0)
        ),
        url("assets/images/background.jpg") center center / cover
        no-repeat fixed !important;
}

/* Remove white background from page wrappers */
main,
.track-page,
.track-container,
.tracking-container {
    background: transparent !important;
}

/* Search / tracking panels */
.track-container,
.tracking-container {
    background: rgba(255, 255, 255, 0.20) !important;
    backdrop-filter: blur(5px) !important;
    -webkit-backdrop-filter: blur(5px) !important;

    border: 1px solid rgba(255, 255, 255, 0.55) !important;
    box-shadow: 0 15px 40px rgba(20, 60, 100, 0.12) !important;
}

/* Individual cards */
.track-card,
.tracking-card,
.parcel-card,
.info-card,
.tracking-result,
.track-result,
.parcel-result {
    background: rgba(255, 255, 255, 0.25) !important;

    backdrop-filter: blur(4px) !important;
    -webkit-backdrop-filter: blur(4px) !important;

    border: 1px solid rgba(255, 255, 255, 0.6) !important;
}

/* Header/result area */
.tracking-header,
.track-header {
    background: rgba(255, 255, 255, 0.42) !important;
}

/* Keep navbar professional */
.navbar,
.kc-navbar {
    background: rgba(255, 255, 255, 0.96) !important;
}

</style>

</head>


<body>


<!-- ======================================================
     NAVBAR
====================================================== -->

<nav class="kc-navbar">

    <div class="kc-nav-container">

        <a
            href="index.php"
            class="kc-brand"
        >

            <span class="kc-logo">
                <i class="fa-solid fa-box"></i>
            </span>

            <span class="kc-brand-name">
                Keystone Cargo
            </span>

        </a>


        <div class="kc-nav-links">

            <a href="index.php">
                Home
            </a>

            <a href="about.php">
                About
            </a>

            <a href="services.php">
                Services
            </a>

            <a href="track.php">
                Track Parcel
            </a>

            <a href="contact.php">
                Contact
            </a>

            <a
                href="admin/login.php"
                class="kc-admin"
            >
                Admin Login
            </a>

        </div>

    </div>

</nav>


<!-- ======================================================
     PAGE
====================================================== -->

<main class="track-page">

    <div class="track-container">


        <!-- BACK -->

        <a
            href="index.php"
            class="back-home"
        >

            <i class="fa-solid fa-arrow-left"></i>

            Back to Home

        </a>


        <!-- =================================================
             SEARCH
        ================================================= -->

        <div class="search-card">

            <div class="search-icon">

                <i class="fa-solid fa-location-crosshairs"></i>

            </div>

            <h1>
                Track Your Parcel
            </h1>

            <p>
                Enter your Keystone Cargo tracking number
                to view the latest shipment updates.
            </p>


            <form
                method="GET"
                action="track.php"
                class="search-form"
            >

                <input
                    type="text"
                    name="tracking_number"
                    class="search-input"
                    placeholder="Enter tracking number"
                    value="<?php echo clean($tracking_number); ?>"
                    required
                >

                <button
                    type="submit"
                    class="track-btn"
                >

                    <i class="fa-solid fa-magnifying-glass"></i>

                    Track Parcel

                </button>

            </form>

        </div>


        <!-- =================================================
             ERROR
        ================================================= -->

        <?php if ($error != ""): ?>

            <div class="error-card">

                <i class="fa-solid fa-circle-exclamation"></i>

                <?php echo $error; ?>

            </div>

        <?php endif; ?>


        <?php if ($parcel): ?>


        <!-- =================================================
             RESULT
        ================================================= -->

        <div class="result-card">


            <!-- RESULT HEADER -->

            <div class="result-header">

                <div>

                    <div class="tracking-label">
                        TRACKING NUMBER
                    </div>

                    <div class="tracking-number">
                        <?php
                        echo clean(
                            $parcel['tracking_number']
                        );
                        ?>
                    </div>

                </div>


                <div class="current-status">

                    <span class="status-dot"></span>

                    <?php
                    echo clean(
                        $parcel['status']
                    );
                    ?>

                </div>

            </div>


            <!-- =================================================
                 SENDER / RECEIVER / DELIVERY
            ================================================= -->

            <div class="info-grid">


                <!-- SENDER -->

                <div class="info-card">

                    <div class="info-icon">

                        <i class="fa-solid fa-user"></i>

                    </div>

                    <div class="info-title">
                        SENDER
                    </div>

                    <div class="info-name">

                        <?php
                        echo clean(
                            $parcel['sender_name']
                        );
                        ?>

                    </div>

                    <div class="info-text">

                        <?php
                        echo clean(
                            $parcel['sender_phone']
                        );
                        ?>

                        <br>

                        <?php
                        echo clean(
                            $parcel['sender_address']
                            ?: $parcel['sender_address_customer']
                        );
                        ?>

                    </div>

                </div>


                <!-- RECEIVER -->

                <div class="info-card">

                    <div class="info-icon">

                        <i class="fa-solid fa-user-check"></i>

                    </div>

                    <div class="info-title">
                        RECEIVER
                    </div>

                    <div class="info-name">

                        <?php
                        echo clean(
                            $parcel['receiver_name']
                        );
                        ?>

                    </div>

                    <div class="info-text">

                        <?php
                        echo clean(
                            $parcel['receiver_phone']
                        );
                        ?>

                        <br>

                        <?php
                        echo clean(
                            $parcel['receiver_address']
                        );
                        ?>

                    </div>

                </div>


                <!-- DELIVERY -->

                <div class="info-card">

                    <div class="info-icon">

                        <i class="fa-solid fa-calendar-check"></i>

                    </div>

                    <div class="info-title">
                        ESTIMATED DELIVERY
                    </div>

                    <div class="info-name">

                        <?php
                        echo formatDateOnly(
                            $parcel['estimated_delivery']
                        );
                        ?>

                    </div>

                    <div class="info-text">
                        Expected delivery date
                    </div>

                </div>


            </div>


            <!-- =================================================
                 DELIVERY JOURNEY
            ================================================= -->

            <section class="journey-section">


                <div class="journey-heading">

                    <span class="journey-label">
                        SHIPMENT TRACKING
                    </span>

                    <h2>
                        Delivery Journey
                    </h2>

                    <p>
                        Follow your parcel's latest
                        delivery updates.
                    </p>

                </div>


                <?php if (count($history) > 0): ?>


                    <div class="journey-timeline">


                        <?php foreach (
                            $history
                            as $event
                        ): ?>


                            <?php

                            $status =
                                $event['status'];

                            $icon =
                                getStatusIcon(
                                    $status
                                );

                            ?>


                            <div
                                class="journey-item"
                            >


                                <!-- ICON -->

                                <div
                                    class="journey-icon"
                                >

                                    <i
                                        class="fa-solid <?php echo $icon; ?>"
                                    ></i>

                                </div>


                                <!-- CONTENT -->

                                <div
                                    class="journey-content"
                                >


                                    <div
                                        class="journey-status"
                                    >

                                        <?php
                                        echo clean(
                                            $status
                                        );
                                        ?>

                                    </div>


                                    <div
                                        class="journey-date"
                                    >

                                        <i
                                            class="fa-regular fa-clock"
                                        ></i>

                                        <?php
                                        echo formatDateTime(
                                            $event['updated_at']
                                        );
                                        ?>

                                    </div>


                                    <div
                                        class="journey-update"
                                    >

                                        <i
                                            class="fa-solid fa-circle-info"
                                        ></i>

                                        <span>

                                            <?php

                                            if (
                                                !empty(
                                                    $event['remarks']
                                                )
                                            ) {

                                                echo clean(
                                                    $event['remarks']
                                                );

                                            } else {

                                                echo "Shipment status updated.";

                                            }

                                            ?>

                                        </span>

                                    </div>


                                </div>

                            </div>


                        <?php endforeach; ?>


                    </div>


                <?php else: ?>


                    <!-- NO HISTORY -->

                    <div
                        class="journey-empty"
                    >

                        <div class="empty-icon">

                            <i
                                class="fa-solid fa-clock-rotate-left"
                            ></i>

                        </div>

                        <h3>
                            Tracking updates are being prepared
                        </h3>

                        <p>
                            Your shipment has been registered.
                            Detailed delivery updates will
                            appear here.
                        </p>

                    </div>


                <?php endif; ?>


            </section>


            <!-- =================================================
                 PARCEL DETAILS
            ================================================= -->

            <section
                class="details-section"
            >

                <h2 class="details-title">
                    Parcel Details
                </h2>


                <div class="details-grid">


                    <div class="detail-row">

                        <span class="detail-name">
                            Parcel Type
                        </span>

                        <span class="detail-value">
                            <?php
                            echo clean(
                                $parcel['parcel_type']
                            );
                            ?>
                        </span>

                    </div>


                    <div class="detail-row">

                        <span class="detail-name">
                            Weight
                        </span>

                        <span class="detail-value">

                            <?php
                            echo clean(
                                $parcel['weight']
                            );
                            ?>
                            kg

                        </span>

                    </div>


                    <div class="detail-row">

                        <span class="detail-name">
                            Booking Date
                        </span>

                        <span class="detail-value">

                            <?php
                            echo formatDateOnly(
                                $parcel['booking_date']
                            );
                            ?>

                        </span>

                    </div>


                    <div class="detail-row">

                        <span class="detail-name">
                            Sender Location
                        </span>

                        <span class="detail-value">

                            <?php
                            echo clean(
                                $parcel['sender_address']
                                ?: $parcel['sender_address_customer']
                            );
                            ?>

                        </span>

                    </div>


                    <div class="detail-row">

                        <span class="detail-name">
                            Receiver Location
                        </span>

                        <span class="detail-value">

                            <?php
                            echo clean(
                                $parcel['receiver_address']
                            );
                            ?>

                        </span>

                    </div>


                    <div class="detail-row">

                        <span class="detail-name">
                            Estimated Delivery
                        </span>

                        <span class="detail-value">

                            <?php
                            echo formatDateOnly(
                                $parcel['estimated_delivery']
                            );
                            ?>

                        </span>

                    </div>


                </div>

            </section>


        </div>


        <?php endif; ?>


    </div>

</main>


</body>

</html>