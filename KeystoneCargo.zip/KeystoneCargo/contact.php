<?php
include("includes/header.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Contact Us | Keystone Cargo</title>

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

</head>

<body>

<section class="kc-contact-page">

    <div class="kc-contact-container">

        <!-- PAGE HEADER -->
        <div class="kc-contact-header">

            <div class="kc-contact-main-icon">
                <i class="fas fa-headset"></i>
            </div>

            <h1>
                Contact <span>Keystone Cargo</span>
            </h1>

            <p>
                Have a question about your parcel or our services?
                We're here to help you with your shipping and tracking needs.
            </p>

        </div>


        <!-- CONTACT CONTENT -->
        <div class="kc-contact-grid">


            <!-- LEFT SIDE -->
            <div class="kc-contact-info">

                <div class="kc-contact-info-card">

                    <div class="kc-contact-info-icon">
                        <i class="fas fa-location-dot"></i>
                    </div>

                    <div>
                        <h3>Our Location</h3>

                        <p>
                            Keystone Cargo<br>
                            India
                        </p>
                    </div>

                </div>


                <div class="kc-contact-info-card">

                    <div class="kc-contact-info-icon">
                        <i class="fas fa-phone"></i>
                    </div>

                    <div>
                        <h3>Phone</h3>

                        <p>
                            +91 00000 00000
                        </p>
                    </div>

                </div>


                <div class="kc-contact-info-card">

                    <div class="kc-contact-info-icon">
                        <i class="fas fa-envelope"></i>
                    </div>

                    <div>
                        <h3>Email</h3>

                        <p>
                            support@keystonecargo.com
                        </p>
                    </div>

                </div>


                <div class="kc-contact-info-card">

                    <div class="kc-contact-info-icon">
                        <i class="fas fa-clock"></i>
                    </div>

                    <div>
                        <h3>Working Hours</h3>

                        <p>
                            Monday - Saturday<br>
                            9:00 AM - 6:00 PM
                        </p>
                    </div>

                </div>

            </div>


            <!-- RIGHT SIDE -->
            <div class="kc-contact-form-card">

                <div class="kc-contact-form-title">

                    <h2>Send Us a Message</h2>

                    <p>
                        Fill in the details below and we'll get back to you.
                    </p>

                </div>


                <form action="#" method="post">


                    <div class="kc-contact-form-group">

                        <label for="name">
                            Full Name
                        </label>

                        <input
                            type="text"
                            id="name"
                            name="name"
                            placeholder="Enter your name"
                            required
                        >

                    </div>


                    <div class="kc-contact-form-group">

                        <label for="email">
                            Email Address
                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="Enter your email"
                            required
                        >

                    </div>


                    <div class="kc-contact-form-group">

                        <label for="subject">
                            Subject
                        </label>

                        <input
                            type="text"
                            id="subject"
                            name="subject"
                            placeholder="Enter subject"
                            required
                        >

                    </div>


                    <div class="kc-contact-form-group">

                        <label for="message">
                            Message
                        </label>

                        <textarea
                            id="message"
                            name="message"
                            rows="5"
                            placeholder="Write your message..."
                            required
                        ></textarea>

                    </div>


                    <button
                        type="submit"
                        class="kc-contact-submit"
                    >

                        <i class="fas fa-paper-plane"></i>

                        Send Message

                    </button>

                </form>

            </div>

        </div>


        <!-- BACK BUTTON -->
        <div class="kc-contact-back">

            <a
                href="index.php"
                class="kc-contact-back-btn"
            >

                <i class="fas fa-arrow-left"></i>

                Back to Home

            </a>

        </div>

    </div>

</section>


<style>

/* =========================================================
   KEYSTONE CARGO CONTACT PAGE
   ========================================================= */

.kc-contact-page {

    width: 100%;

    min-height: calc(100vh - 88px);

    padding: 70px 5% 85px;

    background:

        radial-gradient(
            circle at 10% 20%,
            rgba(18,104,232,0.10),
            transparent 30%
        ),

        radial-gradient(
            circle at 90% 80%,
            rgba(18,104,232,0.08),
            transparent 30%
        ),

        linear-gradient(
            135deg,
            #f3f7ff,
            #ffffff,
            #eef5ff
        );

}


/* CONTAINER */

.kc-contact-container {

    width: 100%;

    max-width: 1250px;

    margin: 0 auto;

}


/* =========================================================
   HEADER
   ========================================================= */

.kc-contact-header {

    text-align: center;

    max-width: 850px;

    margin: 0 auto 55px;

}


/* ICON */

.kc-contact-main-icon {

    width: 90px;

    height: 90px;

    margin: 0 auto 25px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 22px;

    background:
        linear-gradient(
            135deg,
            #1976f3,
            #075dcc
        );

    color: #ffffff;

    font-size: 35px;

    box-shadow:
        0 18px 40px
        rgba(18,104,232,0.22);

}


/* TITLE */

.kc-contact-header h1 {

    margin: 0 0 18px;

    color: #082b63;

    font-size:
        clamp(40px, 6vw, 65px);

    font-weight: 800;

    letter-spacing: -2px;

}


.kc-contact-header h1 span {

    color: #1268e8;

}


/* DESCRIPTION */

.kc-contact-header p {

    max-width: 780px;

    margin: 0 auto;

    color: #64748b;

    font-size: 17px;

    line-height: 1.8;

}


/* =========================================================
   MAIN GRID
   ========================================================= */

.kc-contact-grid {

    display: grid;

    grid-template-columns:
        0.85fr 1.15fr;

    gap: 35px;

    align-items: stretch;

}


/* =========================================================
   CONTACT INFORMATION
   ========================================================= */

.kc-contact-info {

    display: flex;

    flex-direction: column;

    gap: 18px;

}


/* INFO CARD */

.kc-contact-info-card {

    display: flex;

    align-items: center;

    gap: 18px;

    padding: 24px;

    background: #ffffff;

    border: 1px solid #e1eaf7;

    border-radius: 18px;

    box-shadow:
        0 12px 30px
        rgba(18,104,232,0.06);

    transition: all 0.25s ease;

}


.kc-contact-info-card:hover {

    transform:
        translateX(5px);

    border-color:
        rgba(18,104,232,0.22);

    box-shadow:
        0 18px 38px
        rgba(18,104,232,0.12);

}


/* INFO ICON */

.kc-contact-info-icon {

    width: 54px;

    height: 54px;

    flex-shrink: 0;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 14px;

    background: #eaf3ff;

    color: #1268e8;

    font-size: 21px;

}


/* INFO TITLE */

.kc-contact-info-card h3 {

    margin: 0 0 5px;

    color: #082b63;

    font-size: 18px;

    font-weight: 700;

}


/* INFO TEXT */

.kc-contact-info-card p {

    margin: 0;

    color: #64748b;

    font-size: 14px;

    line-height: 1.7;

}


/* =========================================================
   FORM CARD
   ========================================================= */

.kc-contact-form-card {

    padding: 38px;

    background: #ffffff;

    border: 1px solid #e1eaf7;

    border-radius: 24px;

    box-shadow:
        0 18px 45px
        rgba(18,104,232,0.08);

}


/* FORM TITLE */

.kc-contact-form-title {

    margin-bottom: 28px;

}


.kc-contact-form-title h2 {

    margin: 0 0 8px;

    color: #082b63;

    font-size: 26px;

    font-weight: 700;

}


.kc-contact-form-title p {

    margin: 0;

    color: #64748b;

    font-size: 14px;

}


/* FORM GROUP */

.kc-contact-form-group {

    margin-bottom: 20px;

}


/* LABEL */

.kc-contact-form-group label {

    display: block;

    margin-bottom: 8px;

    color: #263b5a;

    font-size: 14px;

    font-weight: 600;

}


/* INPUT + TEXTAREA */

.kc-contact-form-group input,
.kc-contact-form-group textarea {

    width: 100%;

    padding: 13px 15px;

    border: 1px solid #d6e2f1;

    border-radius: 10px;

    background: #fbfdff;

    color: #172b4d;

    font-size: 14px;

    outline: none;

    resize: vertical;

    transition: all 0.25s ease;

}


.kc-contact-form-group input:focus,
.kc-contact-form-group textarea:focus {

    border-color: #1268e8;

    background: #ffffff;

    box-shadow:
        0 0 0 4px
        rgba(18,104,232,0.09);

}


/* PLACEHOLDER */

.kc-contact-form-group input::placeholder,
.kc-contact-form-group textarea::placeholder {

    color: #9aaac0;

}


/* =========================================================
   SUBMIT BUTTON
   ========================================================= */

.kc-contact-submit {

    width: 100%;

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 9px;

    padding: 14px 25px;

    border: none;

    border-radius: 10px;

    background:
        linear-gradient(
            135deg,
            #1976f3,
            #075dcc
        );

    color: #ffffff;

    font-size: 15px;

    font-weight: 600;

    cursor: pointer;

    box-shadow:
        0 8px 20px
        rgba(18,104,232,0.20);

    transition: all 0.25s ease;

}


.kc-contact-submit:hover {

    transform:
        translateY(-2px);

    box-shadow:
        0 12px 28px
        rgba(18,104,232,0.28);

}


/* =========================================================
   BACK TO HOME
   ========================================================= */

.kc-contact-back {

    display: flex;

    justify-content: center;

    margin-top: 50px;

}


.kc-contact-back-btn {

    display: inline-flex;

    align-items: center;

    gap: 10px;

    padding: 13px 28px;

    border-radius: 30px;

    background: #1268e8;

    color: #ffffff !important;

    font-size: 15px;

    font-weight: 600;

    text-decoration: none !important;

    box-shadow:
        0 8px 22px
        rgba(18,104,232,0.20);

    transition: all 0.25s ease;

}


.kc-contact-back-btn:hover {

    background: #0b55c4;

    color: #ffffff !important;

    transform:
        translateY(-3px);

    box-shadow:
        0 12px 28px
        rgba(18,104,232,0.28);

}


/* =========================================================
   TABLET
   ========================================================= */

@media (max-width: 900px) {

    .kc-contact-grid {

        grid-template-columns: 1fr;

    }

}


/* =========================================================
   MOBILE
   ========================================================= */

@media (max-width: 600px) {

    .kc-contact-page {

        padding:
            50px 6% 65px;

    }


    .kc-contact-header {

        margin-bottom: 40px;

    }


    .kc-contact-main-icon {

        width: 75px;

        height: 75px;

        font-size: 29px;

    }


    .kc-contact-header h1 {

        font-size: 40px;

        letter-spacing: -1px;

    }


    .kc-contact-header p {

        font-size: 15px;

    }


    .kc-contact-form-card {

        padding: 26px 22px;

        border-radius: 20px;

    }


    .kc-contact-info-card {

        padding: 20px;

    }

}

</style>


<?php
include("includes/footer.php");
?>
